/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { TabType, EnglishLevel, SpeechSettings, UserStats, SubscriptionPlan } from './types';
import { AppLanguage, TRANSLATIONS, SUPPORTED_LANGUAGES } from './data/translations';
import { Navbar } from './components/Navbar';
import { ConversationTutor } from './components/ConversationTutor';
import { CurriculumLessons } from './components/CurriculumLessons';
import { SpellingDoctor } from './components/SpellingDoctor';
import { PronunciationLab } from './components/PronunciationLab';
import { IELTSPreparation } from './components/IELTSPreparation';
import { PremiumSubscriptionModal } from './components/PremiumSubscriptionModal';
import { SettingsModal } from './components/SettingsModal';
import {
  Sparkles,
  Mic,
  BookOpen,
  CheckCircle2,
  Volume2,
  Flame,
  ArrowRight,
  ShieldCheck,
  Award,
  Crown,
} from 'lucide-react';

export default function App() {
  // Navigation & Level State
  const [currentTab, setCurrentTab] = useState<TabType>('conversation');
  const [level, setLevel] = useState<EnglishLevel>('beginner');
  const [language, setLanguage] = useState<AppLanguage>('en');
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isSubscriptionModalOpen, setIsSubscriptionModalOpen] = useState(false);
  const [isDark, setIsDark] = useState(false);
  const [isPremium, setIsPremium] = useState(false);

  // User Stats & Persistence
  const [stats, setStats] = useState<UserStats>({
    streakDays: 3,
    lastPracticedDate: new Date().toISOString().split('T')[0],
    totalSpeakingMinutes: 14.5,
    sentencesSpoken: 28,
    completedLessons: ['lesson-beg-1'],
    masteredWords: ['because', 'friend'],
  });

  // Speech Voice Settings
  const [speechSettings, setSpeechSettings] = useState<SpeechSettings>({
    rate: 1.0,
    pitch: 1.0,
    voiceGender: 'female',
    accent: 'US',
  });

  // Load saved state from localStorage
  useEffect(() => {
    try {
      const savedLevel = localStorage.getItem('speakfluent_level') as EnglishLevel;
      if (savedLevel) setLevel(savedLevel);

      const savedDark = localStorage.getItem('speakfluent_dark') === 'true';
      setIsDark(savedDark);
      if (savedDark) {
        document.documentElement.classList.add('dark');
      } else {
        document.documentElement.classList.remove('dark');
      }

      const savedPremium = localStorage.getItem('speakfluent_premium') === 'true';
      setIsPremium(savedPremium);

      const savedLang = localStorage.getItem('speakfluent_lang') as AppLanguage;
      if (savedLang && (savedLang === 'en' || savedLang === 'ur' || savedLang === 'hi' || savedLang === 'ar' || savedLang === 'es')) {
        setLanguage(savedLang);
      }

      const savedStats = localStorage.getItem('speakfluent_stats');
      if (savedStats) {
        setStats(JSON.parse(savedStats));
      }

      const savedSettings = localStorage.getItem('speakfluent_speech');
      if (savedSettings) {
        setSpeechSettings(JSON.parse(savedSettings));
      }
    } catch (e) {
      console.warn('LocalStorage error:', e);
    }
  }, []);

  const handleToggleDark = () => {
    const nextDark = !isDark;
    setIsDark(nextDark);
    localStorage.setItem('speakfluent_dark', String(nextDark));
    if (nextDark) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  };

  const handleSelectLanguage = (newLang: AppLanguage) => {
    setLanguage(newLang);
    localStorage.setItem('speakfluent_lang', newLang);
  };

  const handleUpgradePlan = (plan: SubscriptionPlan) => {
    setIsPremium(true);
    localStorage.setItem('speakfluent_premium', 'true');
  };

  const handleToggleMockPremium = () => {
    const next = !isPremium;
    setIsPremium(next);
    localStorage.setItem('speakfluent_premium', String(next));
  };

  const handleSelectLevel = (newLevel: EnglishLevel) => {
    setLevel(newLevel);
    localStorage.setItem('speakfluent_level', newLevel);
  };

  const handleUpdateSpeechSettings = (newSettings: SpeechSettings) => {
    setSpeechSettings(newSettings);
    localStorage.setItem('speakfluent_speech', JSON.stringify(newSettings));
  };

  const handleIncrementSpeakingMinutes = (minutes: number) => {
    setStats((prev) => {
      const next = {
        ...prev,
        totalSpeakingMinutes: Math.round((prev.totalSpeakingMinutes + minutes) * 10) / 10,
      };
      localStorage.setItem('speakfluent_stats', JSON.stringify(next));
      return next;
    });
  };

  const handleIncrementSentences = () => {
    setStats((prev) => {
      const next = {
        ...prev,
        sentencesSpoken: prev.sentencesSpoken + 1,
      };
      localStorage.setItem('speakfluent_stats', JSON.stringify(next));
      return next;
    });
  };

  const handleCompleteLesson = (lessonId: string) => {
    setStats((prev) => {
      if (prev.completedLessons.includes(lessonId)) return prev;
      const next = {
        ...prev,
        completedLessons: [...prev.completedLessons, lessonId],
      };
      localStorage.setItem('speakfluent_stats', JSON.stringify(next));
      return next;
    });
  };

  const t = TRANSLATIONS[language] || TRANSLATIONS.en;

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 flex flex-col transition-colors">
      {/* 1. Global Navigation Bar */}
      <Navbar
        currentTab={currentTab}
        onSelectTab={setCurrentTab}
        level={level}
        onSelectLevel={handleSelectLevel}
        streakDays={stats.streakDays}
        onOpenSettings={() => setIsSettingsOpen(true)}
        isDark={isDark}
        onToggleDark={handleToggleDark}
        isPremium={isPremium}
        onOpenSubscriptionModal={() => setIsSubscriptionModalOpen(true)}
        language={language}
        onSelectLanguage={handleSelectLanguage}
      />

      {/* 2. Hero & Quick Practice Strip */}
      <section className="border-b border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900/60 transition-colors">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-10">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            {/* Left Headline & Scope */}
            <div className="lg:col-span-7 space-y-4">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-50 dark:bg-amber-950/50 border border-amber-200 dark:border-amber-800/60 text-xs font-semibold text-amber-800 dark:text-amber-300">
                <Sparkles className="w-3.5 h-3.5" />
                <span>{t.hero.badge}</span>
              </div>

              <h1 className="text-3xl sm:text-4xl lg:text-5xl font-black tracking-tight text-slate-900 dark:text-white leading-[1.15]">
                {t.hero.title}
              </h1>

              <p className="text-base text-slate-600 dark:text-slate-300 max-w-2xl leading-relaxed">
                {t.hero.subtitle}
              </p>

              {/* Action Buttons & Fast Switcher */}
              <div className="flex flex-wrap items-center gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setCurrentTab('ielts')}
                  className="flex items-center gap-2 px-5 py-3 rounded-xl bg-amber-500 hover:bg-amber-600 text-slate-950 font-black text-sm shadow-xs transition-transform active:scale-95 cursor-pointer"
                >
                  <Award className="w-4 h-4 fill-slate-950" />
                  <span>{t.hero.ieltsMock}</span>
                </button>

                <button
                  type="button"
                  onClick={() => setCurrentTab('conversation')}
                  className="flex items-center gap-2 px-5 py-3 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 font-semibold text-sm transition-colors cursor-pointer"
                >
                  <Mic className="w-4 h-4 text-amber-600" />
                  <span>{t.hero.startSpeaking}</span>
                </button>

                <button
                  type="button"
                  onClick={() => setCurrentTab('polisher')}
                  className="flex items-center gap-2 px-5 py-3 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 font-semibold text-sm transition-colors cursor-pointer"
                >
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  <span>{t.hero.spellingDoctor}</span>
                </button>
              </div>

              {/* Learning Stats Strip */}
              <div className="pt-4 flex items-center gap-6 text-xs text-slate-500 dark:text-slate-400">
                <div>
                  <span className="font-extrabold text-slate-900 dark:text-white text-base">
                    {stats.totalSpeakingMinutes}
                  </span>{' '}
                  {t.hero.minsSpoken}
                </div>
                <div className="h-4 w-px bg-slate-200 dark:bg-slate-800" />
                <div>
                  <span className="font-extrabold text-slate-900 dark:text-white text-base">
                    {stats.sentencesSpoken}
                  </span>{' '}
                  {t.hero.sentences}
                </div>
                <div className="h-4 w-px bg-slate-200 dark:bg-slate-800" />
                <div>
                  <span className="font-extrabold text-slate-900 dark:text-white text-base">
                    {stats.completedLessons.length}
                  </span>{' '}
                  {t.hero.mastered}
                </div>
              </div>
            </div>

            {/* Right Hero Image Card */}
            <div className="lg:col-span-5 relative">
              <div className="relative rounded-3xl overflow-hidden shadow-lg border border-slate-200 dark:border-slate-800 group">
                <img
                  src="/src/assets/images/hero_english_speaking_1794123684699.jpg"
                  alt="Students happily conversing in English"
                  className="w-full h-64 sm:h-72 object-cover transition-transform duration-500 group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-slate-950/20 to-transparent flex flex-col justify-end p-6 text-white">
                  <div className="flex items-center gap-2 text-xs font-semibold text-amber-400 mb-1">
                    <Volume2 className="w-3.5 h-3.5" />
                    <span>Active Audio Synthesis & Speech AI</span>
                  </div>
                  <h3 className="text-lg font-bold">
                    Natural Flow & Spoken Confidence
                  </h3>
                  <p className="text-xs text-slate-300 mt-0.5">
                    Listen to clear native accents and receive instantaneous feedback.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 3. Main Interactive Work Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-10">
        {currentTab === 'ielts' && (
          <IELTSPreparation
            isPremium={isPremium}
            onOpenSubscriptionModal={() => setIsSubscriptionModalOpen(true)}
            speechSettings={speechSettings}
            onIncrementSpeakingMinutes={handleIncrementSpeakingMinutes}
            onIncrementSentences={handleIncrementSentences}
            language={language}
          />
        )}

        {currentTab === 'conversation' && (
          <ConversationTutor
            level={level}
            speechSettings={speechSettings}
            onIncrementSpeakingMinutes={handleIncrementSpeakingMinutes}
            onIncrementSentences={handleIncrementSentences}
            language={language}
          />
        )}

        {currentTab === 'curriculum' && (
          <CurriculumLessons
            level={level}
            speechSettings={speechSettings}
            completedLessons={stats.completedLessons}
            onCompleteLesson={handleCompleteLesson}
            onIncrementSpeakingMinutes={handleIncrementSpeakingMinutes}
            onIncrementSentences={handleIncrementSentences}
          />
        )}

        {currentTab === 'polisher' && (
          <SpellingDoctor
            level={level}
            speechSettings={speechSettings}
            onIncrementSpeakingMinutes={handleIncrementSpeakingMinutes}
            onIncrementSentences={handleIncrementSentences}
          />
        )}

        {currentTab === 'pronunciation' && (
          <PronunciationLab
            speechSettings={speechSettings}
            onIncrementSpeakingMinutes={handleIncrementSpeakingMinutes}
            onIncrementSentences={handleIncrementSentences}
          />
        )}
      </main>

      {/* 4. Quiet Footer adhering to anti-slop guidelines */}
      <footer className="border-t border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900/60 py-6 text-xs text-slate-500 dark:text-slate-400 transition-colors">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2.5">
            <img
              src="/src/assets/images/app_icon_speakfluent_1794130126869.jpg"
              alt="SpeakFluent"
              className="w-6 h-6 rounded-md object-cover shadow-2xs ring-1 ring-amber-500/20"
            />
            <span className="font-bold text-slate-800 dark:text-slate-200">
              SpeakFluent English
            </span>
            <span>·</span>
            <span>Spoken, Spelling & IELTS Mastery</span>
          </div>

          <div className="flex items-center gap-6">
            <button
              onClick={() => setCurrentTab('ielts')}
              className="hover:text-slate-900 dark:hover:text-white transition-colors"
            >
              IELTS Mock Tests
            </button>
            <button
              onClick={() => setCurrentTab('curriculum')}
              className="hover:text-slate-900 dark:hover:text-white transition-colors"
            >
              Curriculum
            </button>
            <button
              onClick={() => setCurrentTab('polisher')}
              className="hover:text-slate-900 dark:hover:text-white transition-colors"
            >
              Spelling Doctor
            </button>
            <button
              onClick={() => setCurrentTab('pronunciation')}
              className="hover:text-slate-900 dark:hover:text-white transition-colors"
            >
              Phonetics Lab
            </button>
          </div>
        </div>
      </footer>

      {/* Settings Modal */}
      <SettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        settings={speechSettings}
        onUpdateSettings={handleUpdateSpeechSettings}
        level={level}
        onUpdateLevel={handleSelectLevel}
      />

      {/* Premium Subscription / Fee Lock Modal */}
      <PremiumSubscriptionModal
        isOpen={isSubscriptionModalOpen}
        onClose={() => setIsSubscriptionModalOpen(false)}
        isPremium={isPremium}
        onUpgrade={handleUpgradePlan}
        onToggleMockPremium={handleToggleMockPremium}
      />
    </div>
  );
}
