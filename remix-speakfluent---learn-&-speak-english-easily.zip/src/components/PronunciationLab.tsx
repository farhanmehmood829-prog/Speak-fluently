import React, { useState } from 'react';
import { PRONUNCIATION_WORDS, TONGUE_TWISTERS } from '../data/curriculumData';
import { PronunciationItem, TongueTwister, SpeechSettings } from '../types';
import { speakText, stopSpeaking, SpeechRecognizer, isSpeechRecognitionSupported } from '../utils/speech';
import { AudioVisualizer } from './AudioVisualizer';
import {
  Volume2,
  Mic,
  MicOff,
  Sparkles,
  Trophy,
  CheckCircle2,
  AlertCircle,
  RotateCcw,
  Timer,
} from 'lucide-react';
import confetti from 'canvas-confetti';

interface PronunciationLabProps {
  speechSettings: SpeechSettings;
  onIncrementSpeakingMinutes: (minutes: number) => void;
  onIncrementSentences: () => void;
}

export const PronunciationLab: React.FC<PronunciationLabProps> = ({
  speechSettings,
  onIncrementSpeakingMinutes,
  onIncrementSentences,
}) => {
  const [activeTab, setActiveTab] = useState<'words' | 'twisters'>('words');

  // Word Drill State
  const [selectedWord, setSelectedWord] = useState<PronunciationItem>(PRONUNCIATION_WORDS[0]);
  const [isRecordingWord, setIsRecordingWord] = useState(false);
  const [isEvaluating, setIsEvaluating] = useState(false);
  const [wordEvaluation, setWordEvaluation] = useState<any>(null);

  // Tongue Twister State
  const [selectedTwister, setSelectedTwister] = useState<TongueTwister>(TONGUE_TWISTERS[0]);
  const [isRecordingTwister, setIsRecordingTwister] = useState(false);
  const [twisterSpokenText, setTwisterSpokenText] = useState('');
  const [twisterScore, setTwisterScore] = useState<number | null>(null);

  const handlePlayWord = (text: string) => {
    speakText(text, speechSettings);
  };

  const handleRecordWord = () => {
    if (isRecordingWord) {
      setIsRecordingWord(false);
      return;
    }

    if (!isSpeechRecognitionSupported()) {
      alert('Speech recognition is not supported in this browser. Please use Chrome.');
      return;
    }

    setIsRecordingWord(true);
    setWordEvaluation(null);

    const recognizer = new SpeechRecognizer(
      async (transcript, isFinal) => {
        if (isFinal || transcript.trim().length > 0) {
          setIsRecordingWord(false);
          setIsEvaluating(true);
          onIncrementSpeakingMinutes(0.5);
          onIncrementSentences();

          try {
            const res = await fetch('/api/pronunciation-evaluate', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({
                targetText: selectedWord.word,
                spokenText: transcript,
              }),
            });
            const data = await res.json();
            setWordEvaluation({ ...data, userSpoken: transcript });
            if (data.accuracyScore >= 80) {
              confetti({ particleCount: 40, spread: 50, origin: { y: 0.6 } });
            }
          } catch (e) {
            console.error('Pronunciation evaluation error:', e);
          } finally {
            setIsEvaluating(false);
          }
        }
      },
      (err) => {
        console.warn(err);
        setIsRecordingWord(false);
      },
      (listening) => {
        setIsRecordingWord(listening);
      }
    );

    recognizer.start();
  };

  const handleRecordTwister = () => {
    if (isRecordingTwister) {
      setIsRecordingTwister(false);
      return;
    }

    if (!isSpeechRecognitionSupported()) {
      alert('Speech recognition is not supported in this browser. Please use Chrome.');
      return;
    }

    setIsRecordingTwister(true);
    setTwisterScore(null);
    setTwisterSpokenText('');

    const recognizer = new SpeechRecognizer(
      (transcript) => {
        setTwisterSpokenText(transcript);
      },
      (err) => {
        console.warn(err);
        setIsRecordingTwister(false);
      },
      (listening) => {
        setIsRecordingTwister(listening);
        if (!listening && twisterSpokenText) {
          onIncrementSpeakingMinutes(0.5);
          onIncrementSentences();

          // Calculate similarity
          const target = selectedTwister.text.toLowerCase().replace(/[^a-z\s]/g, '').split(/\s+/);
          const user = twisterSpokenText.toLowerCase().replace(/[^a-z\s]/g, '').split(/\s+/);
          let match = 0;
          target.forEach((w) => {
            if (user.includes(w)) match++;
          });
          const calculated = Math.min(100, Math.round((match / target.length) * 100));
          setTwisterScore(calculated);
          if (calculated >= 75) {
            confetti({ particleCount: 50, spread: 60, origin: { y: 0.6 } });
          }
        }
      }
    );

    recognizer.start();
  };

  return (
    <div className="space-y-8 max-w-6xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-slate-200 dark:border-slate-800">
        <div>
          <div className="flex items-center gap-2 text-xs font-semibold text-amber-600 dark:text-amber-400 mb-1">
            <Sparkles className="w-4 h-4" />
            <span>Phonetics & Articulation Lab</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-slate-900 dark:text-white">
            Master English Pronunciation & Syllable Stress
          </h2>
          <p className="mt-1 text-sm text-slate-600 dark:text-slate-400">
            Learn where native speakers place stress and conquer notoriously difficult English words.
          </p>
        </div>

        {/* Tab switcher */}
        <div className="flex items-center gap-1 p-1 bg-slate-100 dark:bg-slate-800 rounded-xl text-xs font-semibold shrink-0">
          <button
            onClick={() => setActiveTab('words')}
            className={`px-4 py-2 rounded-lg transition-colors whitespace-nowrap shrink-0 ${
              activeTab === 'words'
                ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            Difficult Words & Syllables
          </button>
          <button
            onClick={() => setActiveTab('twisters')}
            className={`px-4 py-2 rounded-lg transition-colors whitespace-nowrap shrink-0 ${
              activeTab === 'twisters'
                ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            Tongue Twister Challenges
          </button>
        </div>
      </div>

      {/* SECTION 1: DIFFICULT WORDS & SYLLABLES */}
      {activeTab === 'words' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Word Selector sidebar */}
          <div className="lg:col-span-4 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-4 shadow-xs space-y-2">
            <span className="text-xs font-bold text-slate-500 uppercase tracking-wider block mb-2 px-2">
              Select Word to Practice
            </span>
            {PRONUNCIATION_WORDS.map((item) => {
              const active = selectedWord.id === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => {
                    setSelectedWord(item);
                    setWordEvaluation(null);
                  }}
                  className={`w-full text-left p-3 rounded-xl border transition-all cursor-pointer ${
                    active
                      ? 'bg-amber-50 dark:bg-amber-950/40 border-amber-300 dark:border-amber-800 text-amber-900 dark:text-amber-200 font-bold shadow-xs'
                      : 'border-transparent hover:bg-slate-50 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-300'
                  }`}
                >
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-sm font-semibold">{item.word}</span>
                    <span
                      className={`text-[10px] uppercase font-bold px-1.5 py-0.5 rounded-sm ${
                        item.difficulty === 'Challenging'
                          ? 'bg-red-100 text-red-800 dark:bg-red-950 dark:text-red-300'
                          : 'bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300'
                      }`}
                    >
                      {item.difficulty}
                    </span>
                  </div>
                  <span className="text-xs font-mono text-slate-500 block mt-0.5">
                    {item.ipa}
                  </span>
                </button>
              );
            })}
          </div>

          {/* Active Word Studio */}
          <div className="lg:col-span-8 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 sm:p-8 shadow-xs space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-slate-100 dark:border-slate-800">
              <div>
                <span className="text-xs font-bold text-amber-600 dark:text-amber-400">
                  Target Pronunciation
                </span>
                <h3 className="text-3xl font-black text-slate-900 dark:text-white mt-1">
                  {selectedWord.word}
                </h3>
                <div className="flex items-center gap-3 mt-1.5">
                  <span className="text-sm font-mono text-slate-600 dark:text-slate-400">
                    {selectedWord.ipa}
                  </span>
                  <span className="text-slate-300 dark:text-slate-700">·</span>
                  <span className="text-sm font-extrabold text-amber-600 dark:text-amber-400 font-mono tracking-wide">
                    {selectedWord.syllables}
                  </span>
                </div>
              </div>

              {/* Native Voice & Mic Buttons */}
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => handlePlayWord(selectedWord.word)}
                  className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-900 dark:text-white font-bold text-xs transition-colors cursor-pointer"
                >
                  <Volume2 className="w-4 h-4 text-amber-500" />
                  <span>Listen Voice</span>
                </button>

                <button
                  type="button"
                  onClick={handleRecordWord}
                  className={`flex items-center gap-2 px-5 py-2.5 rounded-xl font-bold text-xs transition-all cursor-pointer ${
                    isRecordingWord
                      ? 'bg-red-500 text-white animate-pulse'
                      : 'bg-amber-500 hover:bg-amber-600 text-slate-950 shadow-xs'
                  }`}
                >
                  {isRecordingWord ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
                  <span>{isRecordingWord ? 'Listening...' : 'Record My Voice'}</span>
                </button>
              </div>
            </div>

            {/* Audio Tip & Common Slip */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800">
                <span className="text-xs font-bold text-slate-500 uppercase tracking-wider block mb-1">
                  💡 Native Speaker Tip:
                </span>
                <p className="text-xs text-slate-700 dark:text-slate-300 font-medium">
                  {selectedWord.audioHint}
                </p>
              </div>

              <div className="p-4 rounded-xl bg-amber-50/60 dark:bg-amber-950/20 border border-amber-200 dark:border-amber-900/40">
                <span className="text-xs font-bold text-amber-800 dark:text-amber-300 uppercase tracking-wider block mb-1">
                  ⚠️ Most Common Slip:
                </span>
                <p className="text-xs text-slate-700 dark:text-slate-300 font-medium">
                  {selectedWord.commonSlip}
                </p>
              </div>
            </div>

            {/* In-Context Sentence */}
            <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-950">
              <div className="flex items-center justify-between gap-2 mb-1">
                <span className="text-xs font-semibold text-slate-500">Practice In Context:</span>
                <button
                  onClick={() => handlePlayWord(selectedWord.exampleSentence)}
                  className="p-1 text-slate-400 hover:text-slate-900 dark:hover:text-white"
                >
                  <Volume2 className="w-3.5 h-3.5" />
                </button>
              </div>
              <p className="text-sm font-medium text-slate-900 dark:text-white italic">
                "{selectedWord.exampleSentence}"
              </p>
            </div>

            {/* Evaluation Score result */}
            {isEvaluating && (
              <div className="p-6 rounded-2xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 flex items-center justify-center gap-3">
                <div className="w-5 h-5 border-2 border-amber-500 border-t-transparent rounded-full animate-spin" />
                <span className="text-sm font-semibold text-slate-700 dark:text-slate-300">
                  AI is analyzing your pronunciation acoustic pattern...
                </span>
              </div>
            )}

            {wordEvaluation && (
              <div className="p-6 rounded-2xl bg-emerald-50/70 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-800 space-y-3">
                <div className="flex items-center justify-between gap-4">
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />
                    <span className="font-bold text-base text-emerald-900 dark:text-emerald-200">
                      Pronunciation Score: {wordEvaluation.accuracyScore}%
                    </span>
                  </div>
                  <span className="text-xs font-semibold px-2 py-1 rounded-md bg-emerald-100 dark:bg-emerald-900/60 text-emerald-800 dark:text-emerald-200">
                    {wordEvaluation.pacing || 'Good Pacing'}
                  </span>
                </div>

                <div className="text-xs text-slate-700 dark:text-slate-300">
                  <span>Recognized voice input: </span>
                  <span className="font-bold font-mono">"{wordEvaluation.userSpoken}"</span>
                </div>

                <p className="text-xs text-slate-800 dark:text-slate-200 font-medium">
                  {wordEvaluation.feedback}
                </p>

                {wordEvaluation.confidenceTip && (
                  <div className="pt-2 border-t border-emerald-200/60 dark:border-emerald-800/60 text-xs text-emerald-800 dark:text-emerald-300">
                    🎯 <strong>Coach Advice:</strong> {wordEvaluation.confidenceTip}
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      )}

      {/* SECTION 2: TONGUE TWISTERS */}
      {activeTab === 'twisters' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {TONGUE_TWISTERS.map((twister) => {
            const isSelected = selectedTwister.id === twister.id;
            const isRecording = isSelected && isRecordingTwister;

            return (
              <div
                key={twister.id}
                className={`p-6 rounded-2xl border transition-all bg-white dark:bg-slate-900 shadow-xs flex flex-col justify-between ${
                  isSelected
                    ? 'border-amber-400 dark:border-amber-700 ring-2 ring-amber-500/20'
                    : 'border-slate-200 dark:border-slate-800'
                }`}
              >
                <div>
                  <div className="flex items-center justify-between gap-2 mb-2">
                    <span className="text-xs font-bold text-amber-600 dark:text-amber-400">
                      {twister.title}
                    </span>
                    <span className="text-[10px] font-bold uppercase px-2 py-0.5 rounded-md bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300">
                      {twister.difficulty}
                    </span>
                  </div>

                  <p className="text-base font-extrabold text-slate-900 dark:text-white leading-relaxed my-3">
                    "{twister.text}"
                  </p>

                  <div className="text-xs text-slate-500 dark:text-slate-400 mb-4">
                    🎯 <strong>Target sound:</strong> {twister.focusSound}
                  </div>
                </div>

                <div className="pt-4 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between gap-3">
                  <button
                    type="button"
                    onClick={() => speakText(twister.text, speechSettings)}
                    className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-xs font-bold text-slate-800 dark:text-slate-200 transition-colors"
                  >
                    <Volume2 className="w-4 h-4 text-amber-600" />
                    <span>Listen Native</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      setSelectedTwister(twister);
                      handleRecordTwister();
                    }}
                    className={`flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold transition-all ${
                      isRecording
                        ? 'bg-red-500 text-white animate-pulse'
                        : 'bg-amber-500 hover:bg-amber-600 text-slate-950 shadow-xs'
                    }`}
                  >
                    {isRecording ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
                    <span>{isRecording ? 'Listening...' : 'Try It!'}</span>
                  </button>
                </div>

                {isSelected && twisterScore !== null && (
                  <div className="mt-4 p-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 text-xs text-emerald-900 dark:text-emerald-200 flex items-center justify-between">
                    <span>Your twister clarity score:</span>
                    <span className="font-extrabold text-sm">{twisterScore}%</span>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
