import React from 'react';
import { SpeechSettings, EnglishLevel } from '../types';
import { X, Volume2, Globe, Gauge, Check } from 'lucide-react';
import { speakText } from '../utils/speech';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: SpeechSettings;
  onUpdateSettings: (newSettings: SpeechSettings) => void;
  level: EnglishLevel;
  onUpdateLevel: (lvl: EnglishLevel) => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  settings,
  onUpdateSettings,
  level,
  onUpdateLevel,
}) => {
  if (!isOpen) return null;

  const testVoice = (speed: number, accent: 'US' | 'UK' | 'AU') => {
    speakText("Welcome to SpeakFluent! Let's practice speaking English together.", {
      ...settings,
      rate: speed,
      accent,
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-xs">
      <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-xl max-w-lg w-full p-6 space-y-6">
        <div className="flex items-center justify-between pb-4 border-b border-slate-100 dark:border-slate-800">
          <div className="flex items-center gap-2">
            <Volume2 className="w-5 h-5 text-amber-500" />
            <h3 className="text-lg font-bold text-slate-900 dark:text-white">
              Audio & Learning Preferences
            </h3>
          </div>
          <button
            onClick={onClose}
            aria-label="Close settings"
            className="p-2 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 rounded-xl"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Current Proficiency Level */}
        <div className="space-y-2">
          <label className="text-xs font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider block">
            Proficiency Tier:
          </label>
          <div className="grid grid-cols-3 gap-2">
            {(['beginner', 'intermediate', 'advanced'] as EnglishLevel[]).map((lvl) => (
              <button
                key={lvl}
                onClick={() => onUpdateLevel(lvl)}
                className={`py-2 px-3 rounded-xl border text-xs capitalize font-semibold transition-all ${
                  level === lvl
                    ? 'border-amber-500 bg-amber-50 dark:bg-amber-950/40 text-amber-900 dark:text-amber-200 shadow-xs'
                    : 'border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-50'
                }`}
              >
                {lvl}
              </button>
            ))}
          </div>
        </div>

        {/* Speech Playback Speed */}
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <label className="text-xs font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
              <Gauge className="w-4 h-4 text-amber-500" />
              <span>Voice Speed: {settings.rate}x</span>
            </label>
            <span className="text-[11px] text-slate-500">
              {settings.rate < 1.0 ? 'Slow for learners' : settings.rate === 1.0 ? 'Normal conversational' : 'Fast native flow'}
            </span>
          </div>

          <div className="grid grid-cols-3 gap-2">
            {[0.8, 1.0, 1.15].map((speed) => (
              <button
                key={speed}
                onClick={() => {
                  onUpdateSettings({ ...settings, rate: speed });
                  testVoice(speed, settings.accent);
                }}
                className={`py-2 rounded-xl text-xs font-semibold border transition-all ${
                  settings.rate === speed
                    ? 'border-amber-500 bg-amber-50 dark:bg-amber-950/40 text-amber-900 dark:text-amber-200'
                    : 'border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300'
                }`}
              >
                {speed}x {speed === 0.8 ? '(Slow)' : speed === 1.0 ? '(Normal)' : '(Fast)'}
              </button>
            ))}
          </div>
        </div>

        {/* English Voice Accent */}
        <div className="space-y-2">
          <label className="text-xs font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
            <Globe className="w-4 h-4 text-amber-500" />
            <span>Voice Accent:</span>
          </label>
          <div className="grid grid-cols-3 gap-2">
            {(['US', 'UK', 'AU'] as const).map((accent) => (
              <button
                key={accent}
                onClick={() => {
                  onUpdateSettings({ ...settings, accent });
                  testVoice(settings.rate, accent);
                }}
                className={`py-2 rounded-xl text-xs font-semibold border transition-all ${
                  settings.accent === accent
                    ? 'border-amber-500 bg-amber-50 dark:bg-amber-950/40 text-amber-900 dark:text-amber-200'
                    : 'border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300'
                }`}
              >
                {accent === 'US' ? '🇺🇸 American' : accent === 'UK' ? '🇬🇧 British' : '🇦🇺 Australian'}
              </button>
            ))}
          </div>
        </div>

        <div className="pt-4 border-t border-slate-100 dark:border-slate-800 flex justify-end">
          <button
            onClick={onClose}
            className="px-6 py-2.5 bg-slate-900 dark:bg-amber-500 text-white dark:text-slate-950 rounded-xl font-bold text-xs shadow-xs hover:opacity-90 transition-opacity"
          >
            Save & Done
          </button>
        </div>
      </div>
    </div>
  );
};
