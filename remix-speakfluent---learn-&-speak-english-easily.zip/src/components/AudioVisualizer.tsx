import React from 'react';

interface AudioVisualizerProps {
  isActive: boolean;
  color?: 'amber' | 'emerald' | 'blue';
  label?: string;
}

export const AudioVisualizer: React.FC<AudioVisualizerProps> = ({
  isActive,
  color = 'amber',
  label,
}) => {
  const barColors = {
    amber: 'bg-amber-500 dark:bg-amber-400',
    emerald: 'bg-emerald-500 dark:bg-emerald-400',
    blue: 'bg-sky-500 dark:bg-sky-400',
  };

  const heights = [35, 75, 45, 95, 60, 100, 50, 85, 40, 70, 90, 30];

  return (
    <div className="flex items-center gap-2">
      <div className="flex items-center gap-1 h-6">
        {heights.map((baseHeight, i) => (
          <div
            key={i}
            className={`w-1 rounded-full transition-all duration-150 ${barColors[color]}`}
            style={{
              height: isActive
                ? `${Math.max(15, (baseHeight * (0.4 + ((i % 3) * 0.3))))}%`
                : '20%',
              opacity: isActive ? 0.9 : 0.3,
              animation: isActive ? `bounce 0.8s ease-in-out infinite alternate ${i * 0.08}s` : 'none',
            }}
          />
        ))}
      </div>
      {label && (
        <span className="text-xs font-medium text-slate-500 dark:text-slate-400">
          {label}
        </span>
      )}
    </div>
  );
};
