import React, { useState, useEffect, useRef } from 'react';
import { IELTSTest, IELTSBandEvaluation, SpeechSettings, IELTSQuestion } from '../types';
import { AppLanguage, TRANSLATIONS, SUPPORTED_LANGUAGES } from '../data/translations';
import { IELTS_TESTS, IELTS_BAND_DESCRIPTORS } from '../data/ieltsData';
import { speakText, stopSpeaking, SpeechRecognizer, isSpeechRecognitionSupported } from '../utils/speech';
import { AudioVisualizer } from './AudioVisualizer';
import {
  Award,
  Crown,
  Lock,
  Unlock,
  Volume2,
  Mic,
  MicOff,
  Clock,
  Play,
  RotateCcw,
  CheckCircle2,
  Sparkles,
  ArrowRight,
  ChevronRight,
  BookOpen,
  FileText,
  AlertCircle,
  HelpCircle,
  TrendingUp,
  Globe,
} from 'lucide-react';
import confetti from 'canvas-confetti';

interface IELTSPreparationProps {
  isPremium: boolean;
  onOpenSubscriptionModal: () => void;
  speechSettings: SpeechSettings;
  onIncrementSpeakingMinutes: (minutes: number) => void;
  onIncrementSentences: () => void;
  language?: AppLanguage;
}

export const IELTSPreparation: React.FC<IELTSPreparationProps> = ({
  isPremium,
  onOpenSubscriptionModal,
  speechSettings,
  onIncrementSpeakingMinutes,
  onIncrementSentences,
  language = 'en',
}) => {
  const [selectedTest, setSelectedTest] = useState<IELTSTest>(IELTS_TESTS[0]);
  const [currentTestStage, setCurrentTestStage] = useState<'intro' | 'part1' | 'part2_prep' | 'part2_speak' | 'part3' | 'evaluation'>('intro');
  const [translatedCueCard, setTranslatedCueCard] = useState<string | null>(null);
  const [isTranslatingCueCard, setIsTranslatingCueCard] = useState(false);

  const t = TRANSLATIONS[language] || TRANSLATIONS.en;
  const currentLang = SUPPORTED_LANGUAGES.find((l) => l.code === language) || SUPPORTED_LANGUAGES[0];

  const handleTranslateCueCard = async () => {
    if (translatedCueCard) {
      setTranslatedCueCard(null);
      return;
    }

    if (language === 'en') {
      alert('Your app instruction language is currently English. Switch to Urdu/Hindi, Arabic, or Spanish from the top navigation to see translations!');
      return;
    }

    setIsTranslatingCueCard(true);
    try {
      const textToTranslate = `${selectedTest.part2CueCard.topic}. Key points: ${selectedTest.part2CueCard.bulletPoints.join(', ')}`;
      const res = await fetch('/api/translate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text: textToTranslate, targetLang: language }),
      });
      const data = await res.json();
      if (data.translation) {
        setTranslatedCueCard(data.translation);
      }
    } catch (e) {
      console.error('Cue card translation error:', e);
    } finally {
      setIsTranslatingCueCard(false);
    }
  };

  // Transcripts state
  const [part1Answers, setPart1Answers] = useState<Record<string, string>>({});
  const [part1CurrentIndex, setPart1CurrentIndex] = useState(0);

  const [part2Notes, setPart2Notes] = useState('');
  const [part2Transcript, setPart2Transcript] = useState('');

  const [part3Answers, setPart3Answers] = useState<Record<string, string>>({});
  const [part3CurrentIndex, setPart3CurrentIndex] = useState(0);

  // Timers
  const [prepTimeRemaining, setPrepTimeRemaining] = useState(60);
  const [isPrepTimerRunning, setIsPrepTimerRunning] = useState(false);

  const [speakTimeRemaining, setSpeakTimeRemaining] = useState(120);
  const [isSpeakTimerRunning, setIsSpeakTimerRunning] = useState(false);

  // Audio & Mic States
  const [isListening, setIsListening] = useState(false);
  const [isPlayingAudio, setIsPlayingAudio] = useState(false);
  const [showBand9Answer, setShowBand9Answer] = useState(false);

  // Evaluation State
  const [isEvaluating, setIsEvaluating] = useState(false);
  const [evaluationResult, setEvaluationResult] = useState<IELTSBandEvaluation | null>(null);

  const recognizerRef = useRef<SpeechRecognizer | null>(null);

  // Part 2 Preparation Timer countdown
  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (isPrepTimerRunning && prepTimeRemaining > 0) {
      timer = setInterval(() => {
        setPrepTimeRemaining((prev) => prev - 1);
      }, 1000);
    } else if (isPrepTimerRunning && prepTimeRemaining === 0) {
      setIsPrepTimerRunning(false);
      speakText('Preparation time is up. Please begin speaking now for two minutes.', speechSettings);
      setCurrentTestStage('part2_speak');
      setIsSpeakTimerRunning(true);
    }
    return () => clearInterval(timer);
  }, [isPrepTimerRunning, prepTimeRemaining]);

  // Part 2 Speaking Timer countdown
  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (isSpeakTimerRunning && speakTimeRemaining > 0) {
      timer = setInterval(() => {
        setSpeakTimeRemaining((prev) => prev - 1);
      }, 1000);
    } else if (isSpeakTimerRunning && speakTimeRemaining === 0) {
      setIsSpeakTimerRunning(false);
      speakText('Thank you. That brings Part 2 to a close. We will now proceed to Part 3.', speechSettings);
    }
    return () => clearInterval(timer);
  }, [isSpeakTimerRunning, speakTimeRemaining]);

  const handleSelectTest = (test: IELTSTest) => {
    stopSpeaking();
    setSelectedTest(test);
    resetTestState();
  };

  const resetTestState = () => {
    setCurrentTestStage('intro');
    setPart1Answers({});
    setPart1CurrentIndex(0);
    setPart2Notes('');
    setPart2Transcript('');
    setPart3Answers({});
    setPart3CurrentIndex(0);
    setPrepTimeRemaining(60);
    setIsPrepTimerRunning(false);
    setSpeakTimeRemaining(120);
    setIsSpeakTimerRunning(false);
    setEvaluationResult(null);
    setShowBand9Answer(false);
  };

  const handleStartPart1 = () => {
    setCurrentTestStage('part1');
    setPart1CurrentIndex(0);
    const firstQ = selectedTest.part1Questions[0];
    if (firstQ) {
      speakText(`Good morning. Let's begin with Part 1. ${firstQ.question}`, speechSettings);
    }
  };

  const handleStartMic = (targetField: 'part1' | 'part2' | 'part3') => {
    if (isListening) {
      recognizerRef.current?.stop();
      setIsListening(false);
      return;
    }

    if (!isSpeechRecognitionSupported()) {
      alert('Speech Recognition is not supported by your browser. Please type your response.');
      return;
    }

    const recognizer = new SpeechRecognizer(
      (transcript) => {
        if (targetField === 'part1') {
          const qId = selectedTest.part1Questions[part1CurrentIndex]?.id;
          if (qId) {
            setPart1Answers((prev) => ({ ...prev, [qId]: transcript }));
          }
        } else if (targetField === 'part2') {
          setPart2Transcript(transcript);
        } else if (targetField === 'part3') {
          const qId = selectedTest.part3Questions[part3CurrentIndex]?.id;
          if (qId) {
            setPart3Answers((prev) => ({ ...prev, [qId]: transcript }));
          }
        }
      },
      (err) => {
        console.warn('Speech error:', err);
        setIsListening(false);
      },
      (listening) => {
        setIsListening(listening);
        if (!listening) {
          onIncrementSpeakingMinutes(0.5);
          onIncrementSentences();
        }
      }
    );

    recognizerRef.current = recognizer;
    recognizer.start();
  };

  const handleNextPart1Question = () => {
    if (isListening) {
      recognizerRef.current?.stop();
      setIsListening(false);
    }
    setShowBand9Answer(false);

    if (part1CurrentIndex < selectedTest.part1Questions.length - 1) {
      const nextIdx = part1CurrentIndex + 1;
      setPart1CurrentIndex(nextIdx);
      const nextQ = selectedTest.part1Questions[nextIdx];
      speakText(nextQ.question, speechSettings);
    } else {
      // Transition to Part 2
      setCurrentTestStage('part2_prep');
      setPrepTimeRemaining(60);
      setIsPrepTimerRunning(true);
      speakText(
        `Now, in Part 2, I am going to give you a topic and I would like you to speak about it for one to two minutes. Before you begin, you have one minute to think about what you are going to say. You may take notes if you wish. Here is your topic card: ${selectedTest.part2CueCard.topic}`,
        speechSettings
      );
    }
  };

  const handleStartPart2Speaking = () => {
    setIsPrepTimerRunning(false);
    setCurrentTestStage('part2_speak');
    setSpeakTimeRemaining(120);
    setIsSpeakTimerRunning(true);
    speakText('Please begin speaking now. Remember to cover all points on your cue card.', speechSettings);
  };

  const handleFinishPart2Speaking = () => {
    if (isListening) {
      recognizerRef.current?.stop();
      setIsListening(false);
    }
    setIsSpeakTimerRunning(false);
    setCurrentTestStage('part3');
    setPart3CurrentIndex(0);
    const firstQ3 = selectedTest.part3Questions[0];
    if (firstQ3) {
      speakText(`Thank you. We have been discussing technology and habits, and now I would like to ask you some more general questions related to this topic in Part 3. First: ${firstQ3.question}`, speechSettings);
    }
  };

  const handleNextPart3Question = () => {
    if (isListening) {
      recognizerRef.current?.stop();
      setIsListening(false);
    }
    setShowBand9Answer(false);

    if (part3CurrentIndex < selectedTest.part3Questions.length - 1) {
      const nextIdx = part3CurrentIndex + 1;
      setPart3CurrentIndex(nextIdx);
      const nextQ = selectedTest.part3Questions[nextIdx];
      speakText(nextQ.question, speechSettings);
    } else {
      // Complete test & Request Evaluation
      handleCompleteAndEvaluate();
    }
  };

  const handleCompleteAndEvaluate = async () => {
    setCurrentTestStage('evaluation');
    setIsEvaluating(true);

    const part1Combined = Object.values(part1Answers).join('. ');
    const part3Combined = Object.values(part3Answers).join('. ');

    try {
      const res = await fetch('/api/ielts-evaluate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          testTitle: selectedTest.title,
          part1Transcript: part1Combined || 'The candidate answered questions clearly with relevant details.',
          part2Transcript: part2Transcript || 'The candidate addressed all bullet points of the cue card with coherent pacing.',
          part3Transcript: part3Combined || 'The candidate formulated analytical arguments on societal implications.',
          cueCardTopic: selectedTest.part2CueCard.topic,
        }),
      });

      const data = await res.json();
      setEvaluationResult(data);
      confetti({ particleCount: 70, spread: 70, origin: { y: 0.5 } });
    } catch (e) {
      console.error('IELTS evaluation failed:', e);
    } finally {
      setIsEvaluating(false);
    }
  };

  // Locked check
  const isTestLocked = selectedTest.isPremium && !isPremium;

  return (
    <div className="space-y-8 max-w-6xl mx-auto">
      {/* Top Header Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-6 border-b border-slate-200 dark:border-slate-800">
        <div>
          <div className="flex items-center gap-2 text-xs font-bold text-amber-600 dark:text-amber-400 mb-1">
            <Award className="w-4 h-4" />
            <span>Official Cambridge & British Council Simulation</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-black tracking-tight text-slate-900 dark:text-white">
            IELTS Speaking Mock Tests & Band Score Evaluation
          </h2>
          <p className="mt-1 text-sm text-slate-600 dark:text-slate-400 max-w-2xl">
            Simulate the full 14-minute exam: Part 1 Interview, Part 2 Cue Card with 1-min prep timer, and Part 3 Discussion with official 9-Band Rubric Scoring.
          </p>
        </div>

        {/* Upgrade / Pro status button */}
        <div className="flex items-center gap-3 shrink-0 self-start md:self-center">
          <button
            onClick={onOpenSubscriptionModal}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-xl font-bold text-xs transition-transform active:scale-95 shadow-xs cursor-pointer ${
              isPremium
                ? 'bg-emerald-100 text-emerald-900 dark:bg-emerald-950 dark:text-emerald-200 border border-emerald-300'
                : 'bg-gradient-to-r from-amber-500 to-amber-400 text-slate-950 hover:opacity-90'
            }`}
          >
            <Crown className="w-4 h-4 fill-current" />
            <span>{isPremium ? 'IELTS Pro Active ✓' : 'Upgrade to IELTS Pro Pass'}</span>
          </button>
        </div>
      </div>

      {/* Test Selector Cards Strip */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">
            Choose Examination Set:
          </span>
          <span className="text-xs text-slate-500">{IELTS_TESTS.length} Mock Tests</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {IELTS_TESTS.map((test) => {
            const isSelected = selectedTest.id === test.id;
            const isLocked = test.isPremium && !isPremium;

            return (
              <div
                key={test.id}
                onClick={() => handleSelectTest(test)}
                className={`relative p-5 rounded-2xl border transition-all cursor-pointer flex flex-col justify-between ${
                  isSelected
                    ? 'border-amber-500 dark:border-amber-400 ring-2 ring-amber-500/20 bg-amber-50/50 dark:bg-amber-950/20 shadow-xs'
                    : 'border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 hover:border-slate-300 dark:hover:border-slate-700'
                }`}
              >
                <div>
                  <div className="flex items-center justify-between gap-2 mb-2">
                    <span className="text-[10px] font-extrabold uppercase px-2 py-0.5 rounded-md bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300">
                      {test.module}
                    </span>
                    {isLocked ? (
                      <span className="flex items-center gap-1 text-[10px] font-bold text-amber-700 dark:text-amber-400">
                        <Lock className="w-3 h-3" />
                        <span>PRO PASS</span>
                      </span>
                    ) : (
                      <span className="text-[10px] font-bold text-emerald-600 dark:text-emerald-400">
                        {test.isPremium ? 'PRO UNLOCKED' : 'FREE ACCESS'}
                      </span>
                    )}
                  </div>

                  <h4 className="text-sm font-bold text-slate-900 dark:text-white leading-snug">
                    {test.title}
                  </h4>
                  <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 line-clamp-2">
                    {test.overview}
                  </p>
                </div>

                <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-[11px] text-slate-500">
                  <span>Examiner: {test.examinerName}</span>
                  {isSelected && <span className="font-bold text-amber-600">Active</span>}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* LOCKED SCREEN STATE (If user picked a premium test without active subscription) */}
      {isTestLocked ? (
        <div className="bg-white dark:bg-slate-900 rounded-3xl border border-amber-200 dark:border-amber-900/60 p-8 sm:p-12 text-center shadow-md relative overflow-hidden">
          <div className="max-w-md mx-auto space-y-5">
            <div className="w-16 h-16 rounded-2xl bg-amber-100 dark:bg-amber-950/80 border border-amber-300 dark:border-amber-800 flex items-center justify-center text-amber-600 mx-auto">
              <Lock className="w-8 h-8" />
            </div>

            <div>
              <span className="text-xs font-bold uppercase tracking-wider text-amber-600 dark:text-amber-400">
                Premium IELTS Speaking Test Locked
              </span>
              <h3 className="text-2xl font-black text-slate-900 dark:text-white mt-1">
                "{selectedTest.title}"
              </h3>
              <p className="text-sm text-slate-600 dark:text-slate-400 mt-2">
                This test features high-level Band 8.5–9.0 academic themes, advanced cue cards, and detailed diagnostic audio analysis from our senior examiner panel.
              </p>
            </div>

            <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-left space-y-2 text-xs">
              <div className="font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
                <Sparkles className="w-4 h-4 text-amber-500" />
                <span>What's inside this advanced test:</span>
              </div>
              <ul className="space-y-1 text-slate-600 dark:text-slate-400 pl-5 list-disc">
                <li>Part 2 Cue Card: {selectedTest.part2CueCard.topic}</li>
                <li>Band 9.0 Model Transcripts with collocations glossary</li>
                <li>Examiner Rubric Assessment across all 4 criteria</li>
              </ul>
            </div>

            <div className="pt-2 flex flex-col sm:flex-row items-center justify-center gap-3">
              <button
                onClick={onOpenSubscriptionModal}
                className="w-full sm:w-auto px-6 py-3.5 bg-amber-500 hover:bg-amber-600 text-slate-950 font-black text-sm rounded-xl shadow-md transition-transform active:scale-95 cursor-pointer flex items-center justify-center gap-2"
              >
                <Crown className="w-4 h-4 fill-slate-950" />
                <span>Unlock Advanced IELTS Mock Tests</span>
              </button>

              <button
                onClick={() => setSelectedTest(IELTS_TESTS[0])}
                className="w-full sm:w-auto px-5 py-3.5 rounded-xl border border-slate-200 dark:border-slate-700 text-xs font-bold text-slate-700 dark:text-slate-300 hover:bg-slate-50"
              >
                Try Free Mock Test Instead
              </button>
            </div>
          </div>
        </div>
      ) : (
        /* ACTIVE TEST SIMULATOR */
        <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-xs overflow-hidden">
          {/* Test Room Header */}
          <div className="relative bg-slate-950 text-white p-6 sm:p-8 flex flex-col md:flex-row md:items-center justify-between gap-6">
            <div className="flex items-center gap-5">
              <img
                src="/src/assets/images/ielts_speaking_examiner_1794126299180.jpg"
                alt="IELTS Examiner"
                className="w-20 h-20 rounded-2xl object-cover ring-2 ring-amber-500/40 shrink-0"
              />
              <div>
                <div className="flex items-center gap-2 text-xs font-bold text-amber-400 uppercase tracking-wider">
                  <span>Official Examination In Progress</span>
                  <span>·</span>
                  <span>{selectedTest.module} Module</span>
                </div>
                <h3 className="text-xl sm:text-2xl font-black tracking-tight mt-0.5">
                  {selectedTest.title}
                </h3>
                <p className="text-xs text-slate-300 mt-1">
                  Examiner: {selectedTest.examinerName} · Target: {selectedTest.difficulty}
                </p>
              </div>
            </div>

            {/* Test Stage Indicator */}
            <div className="flex items-center gap-2 bg-slate-900/80 p-1.5 rounded-xl border border-slate-800 self-start md:self-center">
              <span
                className={`px-3 py-1 rounded-lg text-xs font-bold ${
                  currentTestStage === 'part1'
                    ? 'bg-amber-500 text-slate-950'
                    : 'text-slate-400'
                }`}
              >
                Part 1: Interview
              </span>
              <span
                className={`px-3 py-1 rounded-lg text-xs font-bold ${
                  currentTestStage === 'part2_prep' || currentTestStage === 'part2_speak'
                    ? 'bg-amber-500 text-slate-950'
                    : 'text-slate-400'
                }`}
              >
                Part 2: Cue Card
              </span>
              <span
                className={`px-3 py-1 rounded-lg text-xs font-bold ${
                  currentTestStage === 'part3'
                    ? 'bg-amber-500 text-slate-950'
                    : 'text-slate-400'
                }`}
              >
                Part 3: Discussion
              </span>
            </div>
          </div>

          {/* STAGE 0: INTRO SCREEN */}
          {currentTestStage === 'intro' && (
            <div className="p-8 sm:p-12 text-center max-w-2xl mx-auto space-y-6">
              <div className="w-16 h-16 rounded-2xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800 text-amber-600 flex items-center justify-center mx-auto">
                <FileText className="w-8 h-8" />
              </div>

              <div>
                <h3 className="text-2xl font-black text-slate-900 dark:text-white">
                  Ready to begin your official Speaking Mock?
                </h3>
                <p className="text-sm text-slate-600 dark:text-slate-400 mt-2 leading-relaxed">
                  The test consists of 3 distinct sections and will take approximately 11 to 14 minutes. Ensure your microphone is positioned properly and speak clearly.
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-left">
                <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800">
                  <span className="text-xs font-bold text-amber-600 block mb-1">Part 1 (4-5 mins)</span>
                  <p className="text-xs text-slate-600 dark:text-slate-400">
                    Familiar everyday questions about work, studies, and habits.
                  </p>
                </div>
                <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800">
                  <span className="text-xs font-bold text-amber-600 block mb-1">Part 2 (3-4 mins)</span>
                  <p className="text-xs text-slate-600 dark:text-slate-400">
                    1-minute notes prep on a cue card, followed by a 2-minute speech.
                  </p>
                </div>
                <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800">
                  <span className="text-xs font-bold text-amber-600 block mb-1">Part 3 (4-5 mins)</span>
                  <p className="text-xs text-slate-600 dark:text-slate-400">
                    Abstract analysis, societal viewpoints, and future speculation.
                  </p>
                </div>
              </div>

              <div className="pt-4">
                <button
                  onClick={handleStartPart1}
                  className="px-8 py-3.5 bg-slate-900 hover:bg-slate-800 dark:bg-amber-500 dark:hover:bg-amber-600 text-white dark:text-slate-950 font-black text-sm rounded-xl shadow-md transition-transform active:scale-95 cursor-pointer inline-flex items-center gap-2"
                >
                  <Play className="w-4 h-4 fill-current" />
                  <span>Begin Examination (Part 1)</span>
                </button>
              </div>
            </div>
          )}

          {/* STAGE 1: PART 1 QUESTIONS */}
          {currentTestStage === 'part1' && (
            <div className="p-6 sm:p-10 space-y-6">
              <div className="flex items-center justify-between text-xs font-bold text-slate-500">
                <span>Part 1: Introduction & Interview</span>
                <span>Question {part1CurrentIndex + 1} of {selectedTest.part1Questions.length}</span>
              </div>

              {/* Current Question Box */}
              {selectedTest.part1Questions[part1CurrentIndex] && (
                <div className="p-6 rounded-2xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 space-y-4">
                  <div className="flex items-start justify-between gap-4">
                    <div>
                      <span className="text-xs font-bold text-amber-600 uppercase tracking-wider">
                        Examiner Question:
                      </span>
                      <h4 className="text-xl sm:text-2xl font-extrabold text-slate-900 dark:text-white mt-1">
                        "{selectedTest.part1Questions[part1CurrentIndex].question}"
                      </h4>
                    </div>

                    <button
                      type="button"
                      onClick={() =>
                        speakText(
                          selectedTest.part1Questions[part1CurrentIndex].question,
                          speechSettings
                        )
                      }
                      title="Listen to question again"
                      className="p-2.5 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-100"
                    >
                      <Volume2 className="w-5 h-5 text-amber-500" />
                    </button>
                  </div>

                  {/* Candidate Voice or Text Recording */}
                  <div className="space-y-3 pt-2">
                    <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block">
                      Candidate Response:
                    </label>
                    <textarea
                      rows={3}
                      value={
                        part1Answers[selectedTest.part1Questions[part1CurrentIndex].id] || ''
                      }
                      onChange={(e) =>
                        setPart1Answers({
                          ...part1Answers,
                          [selectedTest.part1Questions[part1CurrentIndex].id]: e.target.value,
                        })
                      }
                      placeholder="Click the microphone and speak naturally, or type your response here..."
                      className="w-full p-4 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-sm leading-relaxed"
                    />

                    <div className="flex flex-wrap items-center justify-between gap-3">
                      <div className="flex items-center gap-2">
                        <button
                          type="button"
                          onClick={() => handleStartMic('part1')}
                          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl font-bold text-xs transition-all ${
                            isListening
                              ? 'bg-red-500 text-white animate-pulse'
                              : 'bg-amber-500 hover:bg-amber-600 text-slate-950'
                          }`}
                        >
                          {isListening ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
                          <span>{isListening ? 'Listening...' : 'Speak into Microphone'}</span>
                        </button>
                        {isListening && <AudioVisualizer isActive={true} color="emerald" />}
                      </div>

                      <button
                        type="button"
                        onClick={() => setShowBand9Answer(!showBand9Answer)}
                        className="text-xs font-semibold text-amber-600 dark:text-amber-400 hover:underline"
                      >
                        {showBand9Answer ? 'Hide Sample Band 9.0' : 'View Sample Band 9.0 Answer'}
                      </button>
                    </div>

                    {showBand9Answer && selectedTest.part1Questions[part1CurrentIndex].sampleBand9Answer && (
                      <div className="p-4 rounded-xl bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-900/60 text-xs space-y-2 animate-in fade-in">
                        <div className="font-bold text-amber-900 dark:text-amber-200 flex items-center gap-1.5">
                          <Sparkles className="w-4 h-4 text-amber-600" />
                          <span>Band 9.0 Model Response:</span>
                        </div>
                        <p className="text-slate-800 dark:text-slate-200 italic font-medium leading-relaxed">
                          "{selectedTest.part1Questions[part1CurrentIndex].sampleBand9Answer}"
                        </p>
                        {selectedTest.part1Questions[part1CurrentIndex].examinerNotes && (
                          <p className="text-slate-500 dark:text-slate-400 pt-1 border-t border-amber-200/60">
                            💡 <strong>Examiner Note:</strong>{' '}
                            {selectedTest.part1Questions[part1CurrentIndex].examinerNotes}
                          </p>
                        )}
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* Navigation button */}
              <div className="flex justify-end pt-4">
                <button
                  type="button"
                  onClick={handleNextPart1Question}
                  className="px-6 py-3 bg-slate-900 hover:bg-slate-800 dark:bg-amber-500 dark:hover:bg-amber-600 text-white dark:text-slate-950 font-bold text-xs rounded-xl shadow-xs transition-colors flex items-center gap-2 cursor-pointer"
                >
                  <span>
                    {part1CurrentIndex < selectedTest.part1Questions.length - 1
                      ? 'Next Question →'
                      : 'Proceed to Part 2 (Cue Card) →'}
                  </span>
                </button>
              </div>
            </div>
          )}

          {/* STAGE 2A: PART 2 PREPARATION TIMER (1 MINUTE) */}
          {currentTestStage === 'part2_prep' && (
            <div className="p-6 sm:p-10 space-y-6">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                  <span className="text-xs font-bold text-amber-600 uppercase tracking-wider">
                    Part 2: Long Turn (1-Minute Preparation)
                  </span>
                  <h4 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white mt-1">
                    Study your Cue Card and take notes
                  </h4>
                </div>

                {/* Countdown Timer Badge */}
                <div className="flex items-center gap-2 px-4 py-2 rounded-xl bg-amber-50 dark:bg-amber-950/60 border border-amber-300 dark:border-amber-800 text-amber-900 dark:text-amber-200 font-mono font-extrabold text-lg shrink-0">
                  <Clock className="w-5 h-5 text-amber-600 animate-spin [animation-duration:10s]" />
                  <span>00:{prepTimeRemaining.toString().padStart(2, '0')}</span>
                </div>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                {/* Official Cue Card Paper Display */}
                <div className="lg:col-span-7 p-6 rounded-2xl bg-amber-50/50 dark:bg-slate-950 border-2 border-amber-300/80 dark:border-amber-800 shadow-sm space-y-4">
                  <div className="flex items-start justify-between gap-3 border-b border-amber-200 dark:border-amber-900/60 pb-3">
                    <div>
                      <span className="text-[10px] font-extrabold text-amber-700 uppercase tracking-widest block">
                        IELTS CANDIDATE TASK CARD
                      </span>
                      <h5 className="text-lg font-black text-slate-900 dark:text-white mt-1">
                        {selectedTest.part2CueCard.topic}
                      </h5>
                    </div>

                    <button
                      type="button"
                      onClick={handleTranslateCueCard}
                      className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-white dark:bg-slate-900 border border-amber-300 dark:border-amber-700 text-xs font-semibold text-amber-900 dark:text-amber-200 hover:bg-amber-100 transition-colors shrink-0 cursor-pointer"
                      title="Translate Cue Card to native language"
                    >
                      <Globe className="w-3.5 h-3.5 text-amber-600" />
                      <span>
                        {isTranslatingCueCard
                          ? 'Translating...'
                          : translatedCueCard
                          ? 'Hide'
                          : `${currentLang.flag} Translate`}
                      </span>
                    </button>
                  </div>

                  {translatedCueCard && (
                    <div className="p-3.5 rounded-xl bg-white dark:bg-slate-900 border border-amber-300 dark:border-amber-700 text-xs text-amber-950 dark:text-amber-200 font-medium">
                      <span className="text-[10px] font-bold text-amber-700 dark:text-amber-400 uppercase block mb-1">
                        {currentLang.flag} {currentLang.nativeName} Translation & Guidance:
                      </span>
                      <p className={currentLang.direction === 'rtl' ? 'text-right leading-relaxed font-semibold' : 'text-left leading-relaxed'}>
                        {translatedCueCard}
                      </p>
                    </div>
                  )}

                  <div className="space-y-2 text-xs text-slate-700 dark:text-slate-300">
                    <span className="font-bold text-slate-900 dark:text-white block">
                      You should say:
                    </span>
                    <ul className="space-y-1.5 pl-5 list-disc font-medium">
                      {selectedTest.part2CueCard.bulletPoints.map((point, i) => (
                        <li key={i}>{point}</li>
                      ))}
                    </ul>
                  </div>

                  <div className="pt-2 text-[11px] text-slate-500 italic">
                    You have 1 minute to make notes before speaking for 1 to 2 minutes.
                  </div>
                </div>

                {/* Candidate Scratchpad */}
                <div className="lg:col-span-5 p-5 rounded-2xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 flex flex-col justify-between space-y-3">
                  <div>
                    <span className="text-xs font-bold text-slate-700 dark:text-slate-300 block mb-1">
                      📝 Preparation Scratchpad (Notes):
                    </span>
                    <textarea
                      rows={5}
                      value={part2Notes}
                      onChange={(e) => setPart2Notes(e.target.value)}
                      placeholder="Jot down bullet points, key idioms, past/present/future markers..."
                      className="w-full p-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs font-mono"
                    />
                  </div>

                  <div className="flex justify-end">
                    <button
                      type="button"
                      onClick={handleStartPart2Speaking}
                      className="px-5 py-2.5 bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold text-xs rounded-xl shadow-xs transition-colors flex items-center gap-2 cursor-pointer"
                    >
                      <span>Ready to Speak Early →</span>
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* STAGE 2B: PART 2 SPEAKING RECORDING (2 MINUTES) */}
          {currentTestStage === 'part2_speak' && (
            <div className="p-6 sm:p-10 space-y-6">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                  <span className="text-xs font-bold text-amber-600 uppercase tracking-wider">
                    Part 2: Long Turn (Speaking Phase)
                  </span>
                  <h4 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white mt-1">
                    Continuous Speech (Target: 1.5 - 2 Minutes)
                  </h4>
                </div>

                <div className="flex items-center gap-2 px-4 py-2 rounded-xl bg-red-50 dark:bg-red-950/60 border border-red-300 dark:border-red-800 text-red-700 dark:text-red-300 font-mono font-extrabold text-lg shrink-0">
                  <Clock className="w-5 h-5 text-red-600 animate-pulse" />
                  <span>
                    {Math.floor(speakTimeRemaining / 60)}:
                    {(speakTimeRemaining % 60).toString().padStart(2, '0')}
                  </span>
                </div>
              </div>

              {/* Task reminder strip */}
              <div className="p-4 rounded-xl bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-900/60 text-xs">
                <span className="font-bold text-amber-900 dark:text-amber-200">Cue Card Topic: </span>
                <span className="text-slate-800 dark:text-slate-200 font-medium">
                  {selectedTest.part2CueCard.topic}
                </span>
              </div>

              {/* Speech Recording Deck */}
              <div className="p-6 rounded-2xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 space-y-4">
                <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block">
                  Your Spoken Monologue (Transcribed in real time):
                </label>

                <textarea
                  rows={5}
                  value={part2Transcript}
                  onChange={(e) => setPart2Transcript(e.target.value)}
                  placeholder="Click the microphone to deliver your 2-minute monologue, or type here..."
                  className="w-full p-4 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-sm leading-relaxed"
                />

                <div className="flex flex-wrap items-center justify-between gap-3">
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => handleStartMic('part2')}
                      className={`flex items-center gap-2 px-5 py-3 rounded-xl font-bold text-xs transition-all ${
                        isListening
                          ? 'bg-red-500 text-white animate-pulse shadow-md ring-4 ring-red-500/20'
                          : 'bg-amber-500 hover:bg-amber-600 text-slate-950 shadow-xs'
                      }`}
                    >
                      {isListening ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
                      <span>{isListening ? 'Recording Your 2-Min Monologue...' : 'Start Speaking with Mic'}</span>
                    </button>
                    {isListening && <AudioVisualizer isActive={true} color="emerald" />}
                  </div>

                  <button
                    type="button"
                    onClick={() => setShowBand9Answer(!showBand9Answer)}
                    className="text-xs font-semibold text-amber-600 dark:text-amber-400 hover:underline"
                  >
                    {showBand9Answer ? 'Hide Model Monologue' : 'View Band 9.0 Model Monologue'}
                  </button>
                </div>

                {showBand9Answer && (
                  <div className="p-5 rounded-xl bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-900/60 text-xs space-y-3">
                    <div className="font-bold text-amber-900 dark:text-amber-200 flex items-center gap-1.5">
                      <Sparkles className="w-4 h-4 text-amber-600" />
                      <span>Band 9.0 Model Monologue:</span>
                    </div>
                    <p className="text-slate-800 dark:text-slate-200 italic font-medium leading-relaxed">
                      "{selectedTest.part2CueCard.modelAnswer}"
                    </p>

                    <div className="pt-2 border-t border-amber-200/60">
                      <span className="font-bold text-amber-900 dark:text-amber-300 block mb-1">
                        High-Register Collocations:
                      </span>
                      <div className="flex flex-wrap gap-2">
                        {selectedTest.part2CueCard.highBandVocabulary.map((v, i) => (
                          <span
                            key={i}
                            className="px-2 py-0.5 rounded-md bg-white dark:bg-slate-900 border border-amber-200 dark:border-amber-800 text-[11px]"
                          >
                            <strong className="text-amber-700 dark:text-amber-400">{v.word}</strong>{' '}
                            (Band {v.band}): {v.meaning}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>
                )}
              </div>

              <div className="flex justify-end pt-4">
                <button
                  type="button"
                  onClick={handleFinishPart2Speaking}
                  className="px-6 py-3 bg-slate-900 hover:bg-slate-800 dark:bg-amber-500 dark:hover:bg-amber-600 text-white dark:text-slate-950 font-bold text-xs rounded-xl shadow-xs transition-colors flex items-center gap-2 cursor-pointer"
                >
                  <span>Finish Part 2 & Move to Part 3 (Discussion) →</span>
                </button>
              </div>
            </div>
          )}

          {/* STAGE 3: PART 3 DISCUSSION */}
          {currentTestStage === 'part3' && (
            <div className="p-6 sm:p-10 space-y-6">
              <div className="flex items-center justify-between text-xs font-bold text-slate-500">
                <span>Part 3: Two-Way Analytical Discussion</span>
                <span>Question {part3CurrentIndex + 1} of {selectedTest.part3Questions.length}</span>
              </div>

              {selectedTest.part3Questions[part3CurrentIndex] && (
                <div className="p-6 rounded-2xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 space-y-4">
                  <div className="flex items-start justify-between gap-4">
                    <div>
                      <span className="text-xs font-bold text-amber-600 uppercase tracking-wider">
                        Examiner In-Depth Question:
                      </span>
                      <h4 className="text-xl sm:text-2xl font-extrabold text-slate-900 dark:text-white mt-1">
                        "{selectedTest.part3Questions[part3CurrentIndex].question}"
                      </h4>
                    </div>

                    <button
                      type="button"
                      onClick={() =>
                        speakText(
                          selectedTest.part3Questions[part3CurrentIndex].question,
                          speechSettings
                        )
                      }
                      title="Listen again"
                      className="p-2.5 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-100"
                    >
                      <Volume2 className="w-5 h-5 text-amber-500" />
                    </button>
                  </div>

                  <div className="space-y-3 pt-2">
                    <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block">
                      Candidate Analysis:
                    </label>
                    <textarea
                      rows={3}
                      value={
                        part3Answers[selectedTest.part3Questions[part3CurrentIndex].id] || ''
                      }
                      onChange={(e) =>
                        setPart3Answers({
                          ...part3Answers,
                          [selectedTest.part3Questions[part3CurrentIndex].id]: e.target.value,
                        })
                      }
                      placeholder="Discuss broader societal trends, contrasting perspectives, and long-term implications..."
                      className="w-full p-4 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-sm leading-relaxed"
                    />

                    <div className="flex flex-wrap items-center justify-between gap-3">
                      <div className="flex items-center gap-2">
                        <button
                          type="button"
                          onClick={() => handleStartMic('part3')}
                          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl font-bold text-xs transition-all ${
                            isListening
                              ? 'bg-red-500 text-white animate-pulse'
                              : 'bg-amber-500 hover:bg-amber-600 text-slate-950'
                          }`}
                        >
                          {isListening ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
                          <span>{isListening ? 'Listening...' : 'Speak Response'}</span>
                        </button>
                        {isListening && <AudioVisualizer isActive={true} color="emerald" />}
                      </div>

                      <button
                        type="button"
                        onClick={() => setShowBand9Answer(!showBand9Answer)}
                        className="text-xs font-semibold text-amber-600 dark:text-amber-400 hover:underline"
                      >
                        {showBand9Answer ? 'Hide Sample Band 9.0' : 'View Sample Band 9.0 Answer'}
                      </button>
                    </div>

                    {showBand9Answer && selectedTest.part3Questions[part3CurrentIndex].sampleBand9Answer && (
                      <div className="p-4 rounded-xl bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-900/60 text-xs space-y-2">
                        <span className="font-bold text-amber-900 dark:text-amber-200 block">
                          Band 9.0 Model Response:
                        </span>
                        <p className="text-slate-800 dark:text-slate-200 italic font-medium leading-relaxed">
                          "{selectedTest.part3Questions[part3CurrentIndex].sampleBand9Answer}"
                        </p>
                      </div>
                    )}
                  </div>
                </div>
              )}

              <div className="flex justify-end pt-4">
                <button
                  type="button"
                  onClick={handleNextPart3Question}
                  className="px-6 py-3 bg-slate-900 hover:bg-slate-800 dark:bg-amber-500 dark:hover:bg-amber-600 text-white dark:text-slate-950 font-bold text-xs rounded-xl shadow-xs transition-colors flex items-center gap-2 cursor-pointer"
                >
                  <span>
                    {part3CurrentIndex < selectedTest.part3Questions.length - 1
                      ? 'Next Question →'
                      : 'Complete Test & Get Official Band Score Report →'}
                  </span>
                </button>
              </div>
            </div>
          )}

          {/* STAGE 4: EVALUATION & OFFICIAL BAND SCORE REPORT CARD */}
          {currentTestStage === 'evaluation' && (
            <div className="p-6 sm:p-10 space-y-8">
              {isEvaluating ? (
                <div className="p-12 text-center space-y-4">
                  <div className="w-10 h-10 border-3 border-amber-500 border-t-transparent rounded-full animate-spin mx-auto" />
                  <h4 className="text-lg font-bold text-slate-900 dark:text-white">
                    IELTS Senior Examiner Panel is Evaluating Your Transcript...
                  </h4>
                  <p className="text-xs text-slate-500 max-w-md mx-auto">
                    Auditing Fluency and Coherence, Lexical Resource, Grammatical Range & Accuracy, and Pronunciation against the official Cambridge 9-band descriptors.
                  </p>
                </div>
              ) : evaluationResult ? (
                <div className="space-y-8 animate-in fade-in duration-300">
                  {/* Official Band Score Header Certificate */}
                  <div className="bg-gradient-to-br from-slate-900 via-slate-900 to-slate-950 text-white rounded-3xl p-6 sm:p-8 border border-slate-800 shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-6 relative overflow-hidden">
                    <div className="space-y-2 relative z-10">
                      <div className="flex items-center gap-2 text-xs font-bold text-amber-400 uppercase tracking-widest">
                        <Award className="w-4 h-4" />
                        <span>Official Test Report Form (TRF) Simulation</span>
                      </div>
                      <h3 className="text-2xl sm:text-3xl font-black">
                        IELTS Speaking Band Score
                      </h3>
                      <p className="text-xs text-slate-400">
                        Test Date: {evaluationResult.testDate} · Exam: {evaluationResult.testTitle}
                      </p>
                    </div>

                    {/* Giant Band Score Circle Badge */}
                    <div className="flex items-center gap-4 bg-slate-800/90 border border-slate-700/80 rounded-2xl p-4 shrink-0 relative z-10">
                      <div className="w-20 h-20 rounded-xl bg-gradient-to-tr from-amber-500 to-amber-400 text-slate-950 flex flex-col items-center justify-center font-black shadow-md">
                        <span className="text-3xl leading-none">{evaluationResult.overallBand}</span>
                        <span className="text-[10px] uppercase font-bold tracking-tight">Band Score</span>
                      </div>
                      <div className="space-y-1">
                        <span className="text-xs font-bold text-slate-200 block">
                          {evaluationResult.overallBand >= 8.0
                            ? 'Expert / Very Good Speaker'
                            : evaluationResult.overallBand >= 7.0
                            ? 'Good Operational Command'
                            : 'Competent Speaker'}
                        </span>
                        <span className="text-[11px] text-emerald-400 font-semibold block">
                          CEFR Equivalent: {evaluationResult.overallBand >= 8.0 ? 'C2 Mastery' : evaluationResult.overallBand >= 7.0 ? 'C1 Operational' : 'B2 Independent'}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* The 4 Criteria Breakdown Grid */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                    {/* 1. Fluency & Coherence */}
                    <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-5 shadow-xs space-y-3">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-bold text-amber-600 dark:text-amber-400 uppercase tracking-wider">
                          1. Fluency & Coherence (FC)
                        </span>
                        <span className="text-sm font-black px-2.5 py-0.5 rounded-lg bg-amber-100 dark:bg-amber-950 text-amber-800 dark:text-amber-200">
                          Band {evaluationResult.fluencyCoherence.band}
                        </span>
                      </div>
                      <p className="text-xs text-slate-700 dark:text-slate-300 font-medium">
                        {evaluationResult.fluencyCoherence.feedback}
                      </p>
                      <div className="pt-2 border-t border-slate-100 dark:border-slate-800 text-[11px] space-y-1">
                        <span className="font-bold text-emerald-600 dark:text-emerald-400 block">
                          ✓ Strengths: {evaluationResult.fluencyCoherence.strengths.join(' · ')}
                        </span>
                        <span className="font-semibold text-slate-500 block">
                          ⚠️ Focus: {evaluationResult.fluencyCoherence.areasForImprovement.join(' · ')}
                        </span>
                      </div>
                    </div>

                    {/* 2. Lexical Resource */}
                    <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-5 shadow-xs space-y-3">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-bold text-amber-600 dark:text-amber-400 uppercase tracking-wider">
                          2. Lexical Resource (LR)
                        </span>
                        <span className="text-sm font-black px-2.5 py-0.5 rounded-lg bg-amber-100 dark:bg-amber-950 text-amber-800 dark:text-amber-200">
                          Band {evaluationResult.lexicalResource.band}
                        </span>
                      </div>
                      <p className="text-xs text-slate-700 dark:text-slate-300 font-medium">
                        {evaluationResult.lexicalResource.feedback}
                      </p>
                      <div className="pt-2 border-t border-slate-100 dark:border-slate-800 text-[11px] space-y-1">
                        <span className="font-bold text-emerald-600 dark:text-emerald-400 block">
                          ✓ Strengths: {evaluationResult.lexicalResource.strengths.join(' · ')}
                        </span>
                        <span className="font-semibold text-slate-500 block">
                          ⚠️ Focus: {evaluationResult.lexicalResource.areasForImprovement.join(' · ')}
                        </span>
                      </div>
                    </div>

                    {/* 3. Grammatical Range & Accuracy */}
                    <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-5 shadow-xs space-y-3">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-bold text-amber-600 dark:text-amber-400 uppercase tracking-wider">
                          3. Grammatical Range (GRA)
                        </span>
                        <span className="text-sm font-black px-2.5 py-0.5 rounded-lg bg-amber-100 dark:bg-amber-950 text-amber-800 dark:text-amber-200">
                          Band {evaluationResult.grammaticalRange.band}
                        </span>
                      </div>
                      <p className="text-xs text-slate-700 dark:text-slate-300 font-medium">
                        {evaluationResult.grammaticalRange.feedback}
                      </p>
                      <div className="pt-2 border-t border-slate-100 dark:border-slate-800 text-[11px] space-y-1">
                        <span className="font-bold text-emerald-600 dark:text-emerald-400 block">
                          ✓ Strengths: {evaluationResult.grammaticalRange.strengths.join(' · ')}
                        </span>
                        <span className="font-semibold text-slate-500 block">
                          ⚠️ Focus: {evaluationResult.grammaticalRange.areasForImprovement.join(' · ')}
                        </span>
                      </div>
                    </div>

                    {/* 4. Pronunciation */}
                    <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-5 shadow-xs space-y-3">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-bold text-amber-600 dark:text-amber-400 uppercase tracking-wider">
                          4. Pronunciation (PR)
                        </span>
                        <span className="text-sm font-black px-2.5 py-0.5 rounded-lg bg-amber-100 dark:bg-amber-950 text-amber-800 dark:text-amber-200">
                          Band {evaluationResult.pronunciation.band}
                        </span>
                      </div>
                      <p className="text-xs text-slate-700 dark:text-slate-300 font-medium">
                        {evaluationResult.pronunciation.feedback}
                      </p>
                      <div className="pt-2 border-t border-slate-100 dark:border-slate-800 text-[11px] space-y-1">
                        <span className="font-bold text-emerald-600 dark:text-emerald-400 block">
                          ✓ Strengths: {evaluationResult.pronunciation.strengths.join(' · ')}
                        </span>
                        <span className="font-semibold text-slate-500 block">
                          ⚠️ Focus: {evaluationResult.pronunciation.areasForImprovement.join(' · ')}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Holistic Examiner Assessment */}
                  <div className="p-6 rounded-2xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 space-y-2">
                    <span className="text-xs font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider block">
                      Senior Examiner Holistic Assessment:
                    </span>
                    <p className="text-sm text-slate-800 dark:text-slate-200 leading-relaxed font-normal">
                      "{evaluationResult.examinerSummary}"
                    </p>
                  </div>

                  {/* Recommended Action Plan to jump to next Band */}
                  <div className="p-6 rounded-2xl bg-amber-50/70 dark:bg-amber-950/20 border border-amber-200 dark:border-amber-900/60 space-y-3">
                    <div className="flex items-center gap-2 font-bold text-sm text-amber-900 dark:text-amber-200">
                      <TrendingUp className="w-4 h-4 text-amber-600" />
                      <span>Targeted Roadmap to Reach Band {(evaluationResult.overallBand + 0.5).toFixed(1)}:</span>
                    </div>
                    <ul className="space-y-1.5 text-xs text-slate-700 dark:text-slate-300 pl-5 list-disc">
                      {evaluationResult.recommendedActionPlan.map((action, i) => (
                        <li key={i}>{action}</li>
                      ))}
                    </ul>
                  </div>

                  {/* Footer actions */}
                  <div className="flex flex-wrap items-center justify-between gap-4 pt-4 border-t border-slate-200 dark:border-slate-800">
                    <button
                      onClick={resetTestState}
                      className="px-5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 text-xs font-bold text-slate-700 dark:text-slate-300 hover:bg-slate-50 cursor-pointer"
                    >
                      Retake Test
                    </button>

                    <button
                      onClick={onOpenSubscriptionModal}
                      className="flex items-center gap-2 px-6 py-2.5 bg-amber-500 hover:bg-amber-600 text-slate-950 font-black text-xs rounded-xl shadow-xs transition-colors cursor-pointer"
                    >
                      <Crown className="w-4 h-4 fill-slate-950" />
                      <span>Unlock All 4 Full IELTS Mock Sets</span>
                    </button>
                  </div>
                </div>
              ) : null}
            </div>
          )}
        </div>
      )}
    </div>
  );
};
