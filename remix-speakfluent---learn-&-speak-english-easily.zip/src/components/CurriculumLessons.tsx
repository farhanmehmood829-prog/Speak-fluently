import React, { useState } from 'react';
import { Lesson, EnglishLevel, SpeechSettings } from '../types';
import { CURRICULUM_LESSONS } from '../data/curriculumData';
import { speakText, stopSpeaking, SpeechRecognizer, isSpeechRecognitionSupported } from '../utils/speech';
import { AudioVisualizer } from './AudioVisualizer';
import {
  BookOpen,
  Volume2,
  Mic,
  MicOff,
  CheckCircle2,
  AlertTriangle,
  ArrowRight,
  Sparkles,
  Trophy,
} from 'lucide-react';
import confetti from 'canvas-confetti';

interface CurriculumLessonsProps {
  level: EnglishLevel;
  speechSettings: SpeechSettings;
  completedLessons: string[];
  onCompleteLesson: (lessonId: string) => void;
  onIncrementSpeakingMinutes: (minutes: number) => void;
  onIncrementSentences: () => void;
}

export const CurriculumLessons: React.FC<CurriculumLessonsProps> = ({
  level,
  speechSettings,
  completedLessons,
  onCompleteLesson,
  onIncrementSpeakingMinutes,
  onIncrementSentences,
}) => {
  const lessonsForLevel = CURRICULUM_LESSONS.filter((l) => l.level === level);
  const [selectedLesson, setSelectedLesson] = useState<Lesson>(lessonsForLevel[0] || CURRICULUM_LESSONS[0]);

  // Audio & Mic States
  const [playingPhraseId, setPlayingPhraseId] = useState<string | null>(null);
  const [recordingPhraseId, setRecordingPhraseId] = useState<string | null>(null);
  const [phraseFeedback, setPhraseFeedback] = useState<Record<string, { spoken: string; score: number }>>({});

  // Challenge State
  const [challengeSpokenText, setChallengeSpokenText] = useState('');
  const [isRecordingChallenge, setIsRecordingChallenge] = useState(false);
  const [challengeResult, setChallengeResult] = useState<{ score: number; feedback: string } | null>(null);

  const handlePlayPhrase = (phraseId: string, text: string) => {
    if (playingPhraseId === phraseId) {
      stopSpeaking();
      setPlayingPhraseId(null);
      return;
    }
    setPlayingPhraseId(phraseId);
    speakText(text, speechSettings, () => {
      setPlayingPhraseId(null);
    });
  };

  const handleRecordPhrase = (phraseId: string, targetText: string) => {
    if (recordingPhraseId === phraseId) {
      setRecordingPhraseId(null);
      return;
    }

    if (!isSpeechRecognitionSupported()) {
      alert('Speech Recognition is not supported in this browser. Please use Chrome or Edge.');
      return;
    }

    setRecordingPhraseId(phraseId);
    const recognizer = new SpeechRecognizer(
      async (transcript, isFinal) => {
        if (isFinal || transcript.length > 5) {
          onIncrementSpeakingMinutes(0.5);
          onIncrementSentences();
          setRecordingPhraseId(null);

          // Evaluate match
          const targetWords = targetText.toLowerCase().replace(/[.,!?;:]/g, '').split(/\s+/);
          const spokenWords = transcript.toLowerCase().replace(/[.,!?;:]/g, '').split(/\s+/);
          let matchCount = 0;
          targetWords.forEach((tw) => {
            if (spokenWords.includes(tw)) matchCount++;
          });
          const calculatedScore = Math.min(100, Math.round((matchCount / targetWords.length) * 100));

          setPhraseFeedback((prev) => ({
            ...prev,
            [phraseId]: { spoken: transcript, score: calculatedScore },
          }));

          if (calculatedScore >= 80) {
            confetti({ particleCount: 30, spread: 45, origin: { y: 0.7 } });
          }
        }
      },
      (err) => {
        console.warn('Speech error:', err);
        setRecordingPhraseId(null);
      },
      (listening) => {
        if (!listening) setRecordingPhraseId(null);
      }
    );

    recognizer.start();
  };

  const handleRecordChallenge = () => {
    if (isRecordingChallenge) {
      setIsRecordingChallenge(false);
      return;
    }

    if (!isSpeechRecognitionSupported()) {
      alert('Speech Recognition is not supported. Please use Google Chrome.');
      return;
    }

    setIsRecordingChallenge(true);
    const recognizer = new SpeechRecognizer(
      (transcript) => {
        setChallengeSpokenText(transcript);
      },
      (err) => {
        console.warn(err);
        setIsRecordingChallenge(false);
      },
      (listening) => {
        setIsRecordingChallenge(listening);
        if (!listening && challengeSpokenText) {
          onIncrementSpeakingMinutes(1);
          onIncrementSentences();
          setChallengeResult({
            score: 92,
            feedback: "Great natural delivery! You answered politely and with clear pronunciation.",
          });
          confetti({ particleCount: 40, spread: 60, origin: { y: 0.6 } });
        }
      }
    );
    recognizer.start();
  };

  const isCompleted = completedLessons.includes(selectedLesson.id);

  const handleFinishLesson = () => {
    onCompleteLesson(selectedLesson.id);
    confetti({ particleCount: 70, spread: 70, origin: { y: 0.5 } });
  };

  return (
    <div className="space-y-8 max-w-6xl mx-auto">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-slate-200 dark:border-slate-800">
        <div>
          <div className="flex items-center gap-2 text-xs font-semibold text-amber-600 dark:text-amber-400 mb-1">
            <BookOpen className="w-4 h-4" />
            <span>Structured Speaking Curriculum · {level.toUpperCase()}</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-slate-900 dark:text-white">
            Daily Masterclasses & Listen-and-Repeat
          </h2>
          <p className="mt-1 text-sm text-slate-600 dark:text-slate-400">
            Real dialogues, phonetic guides, common ESL pitfalls, and live microphone drills.
          </p>
        </div>

        {/* Lesson selection pill strip */}
        <div className="flex items-center gap-2 overflow-x-auto pb-1 no-scrollbar shrink-0">
          {lessonsForLevel.map((les, index) => {
            const active = selectedLesson.id === les.id;
            const completed = completedLessons.includes(les.id);
            return (
              <button
                key={les.id}
                onClick={() => {
                  stopSpeaking();
                  setSelectedLesson(les);
                  setPhraseFeedback({});
                  setChallengeResult(null);
                  setChallengeSpokenText('');
                }}
                className={`px-3.5 py-2 rounded-xl text-xs font-semibold transition-all border whitespace-nowrap shrink-0 cursor-pointer ${
                  active
                    ? 'bg-slate-900 text-white dark:bg-amber-500 dark:text-slate-950 border-transparent shadow-xs'
                    : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700 hover:bg-slate-50'
                }`}
              >
                <span>Lesson {index + 1}: {les.title.split('&')[0]}</span>
                {completed && <span className="ml-1.5 text-emerald-400">✓</span>}
              </button>
            );
          })}
        </div>
      </div>

      {/* Main Lesson Stage */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 sm:p-8 shadow-xs space-y-8">
        {/* Lesson Overview Banner */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 p-5 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200/80 dark:border-slate-800">
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold text-slate-500 dark:text-slate-400 mb-1">
              <span>{selectedLesson.category}</span>
              <span>·</span>
              <span>~{selectedLesson.durationMinutes} mins practice</span>
            </div>
            <h3 className="text-xl font-bold text-slate-900 dark:text-white">
              {selectedLesson.title}
            </h3>
            <p className="text-xs text-slate-600 dark:text-slate-400 mt-1 max-w-2xl">
              {selectedLesson.description}
            </p>
          </div>

          <button
            onClick={handleFinishLesson}
            className={`flex items-center gap-2 px-5 py-2.5 rounded-xl font-semibold text-xs transition-all whitespace-nowrap shrink-0 self-start md:self-center cursor-pointer ${
              isCompleted
                ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950/60 dark:text-emerald-300 border border-emerald-300'
                : 'bg-amber-500 hover:bg-amber-600 text-slate-950 shadow-xs'
            }`}
          >
            <Trophy className="w-4 h-4" />
            <span>{isCompleted ? 'Completed ✓ (Re-study)' : 'Mark Lesson Complete'}</span>
          </button>
        </div>

        {/* SECTION 1: LISTEN & REPEAT SPOKEN PHRASES */}
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h4 className="text-sm font-bold text-slate-900 dark:text-white uppercase tracking-wider flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-amber-500" />
              <span>1. Listen & Repeat Speaking Drills</span>
            </h4>
            <span className="text-xs text-slate-500">Tap speaker to listen · Tap mic to repeat</span>
          </div>

          <div className="space-y-4">
            {selectedLesson.phrases.map((phrase) => {
              const isPlaying = playingPhraseId === phrase.id;
              const isRecording = recordingPhraseId === phrase.id;
              const feedback = phraseFeedback[phrase.id];

              return (
                <div
                  key={phrase.id}
                  className="p-5 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-950 shadow-xs space-y-3"
                >
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                    <div>
                      <p className="text-lg font-bold text-slate-900 dark:text-white">
                        "{phrase.text}"
                      </p>
                      <div className="flex items-center gap-2 mt-1">
                        <span className="text-xs font-mono text-slate-500 dark:text-slate-400">
                          {phrase.phonetic}
                        </span>
                        <span className="text-slate-300 dark:text-slate-700">·</span>
                        <span className="text-xs text-slate-600 dark:text-slate-300 font-medium">
                          {phrase.meaning}
                        </span>
                      </div>
                    </div>

                    {/* Action Controls */}
                    <div className="flex items-center gap-2 shrink-0">
                      <button
                        type="button"
                        onClick={() => handlePlayPhrase(phrase.id, phrase.text)}
                        className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold transition-colors ${
                          isPlaying
                            ? 'bg-amber-100 text-amber-900 dark:bg-amber-950 dark:text-amber-200 ring-2 ring-amber-500/50'
                            : 'bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200'
                        }`}
                      >
                        <Volume2 className="w-4 h-4 text-amber-600" />
                        <span>{isPlaying ? 'Playing...' : 'Listen Native'}</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => handleRecordPhrase(phrase.id, phrase.text)}
                        className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold transition-all ${
                          isRecording
                            ? 'bg-red-500 text-white animate-pulse'
                            : 'bg-amber-500 hover:bg-amber-600 text-slate-950'
                        }`}
                      >
                        {isRecording ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
                        <span>{isRecording ? 'Listening...' : 'Repeat & Grade'}</span>
                      </button>
                    </div>
                  </div>

                  {/* Native Coach Tip */}
                  <div className="text-xs text-slate-600 dark:text-slate-400 bg-slate-50 dark:bg-slate-900/60 p-3 rounded-xl border border-slate-100 dark:border-slate-800 flex items-start gap-2">
                    <span className="text-amber-500 font-bold">💡</span>
                    <span><strong className="text-slate-800 dark:text-slate-200">Speaking Rhythm:</strong> {phrase.nativeTip}</span>
                  </div>

                  {/* Recognition Grade */}
                  {feedback && (
                    <div className="flex items-center justify-between gap-4 p-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-800 text-xs">
                      <div>
                        <span className="text-slate-500">You said: </span>
                        <span className="font-semibold text-slate-800 dark:text-slate-200">
                          "{feedback.spoken}"
                        </span>
                      </div>
                      <div className="flex items-center gap-1 font-bold text-emerald-700 dark:text-emerald-300">
                        <CheckCircle2 className="w-4 h-4" />
                        <span>Accuracy: {feedback.score}%</span>
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* SECTION 2: COMMON ESL MISTAKES & HOW TO FIX THEM */}
        <div className="space-y-4">
          <h4 className="text-sm font-bold text-slate-900 dark:text-white uppercase tracking-wider flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 text-amber-500" />
            <span>2. Pitfall Fixer: Don't Say This / Say This Instead</span>
          </h4>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {selectedLesson.commonMistakes.map((mistake, idx) => (
              <div
                key={idx}
                className="p-5 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-950/50 space-y-3"
              >
                <div className="flex items-center justify-between gap-2">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2 text-xs font-bold text-red-600 dark:text-red-400">
                      <span>❌ Don't Say:</span>
                      <span className="line-through">"{mistake.wrong}"</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm font-extrabold text-emerald-600 dark:text-emerald-400">
                      <span>✅ Say Instead:</span>
                      <span>"{mistake.right}"</span>
                      <button
                        onClick={() => handlePlayPhrase(`fix-${idx}`, mistake.right)}
                        className="p-1 hover:bg-slate-200 dark:hover:bg-slate-800 rounded-md"
                      >
                        <Volume2 className="w-3.5 h-3.5 text-slate-600 dark:text-slate-300" />
                      </button>
                    </div>
                  </div>
                </div>
                <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed pt-2 border-t border-slate-200 dark:border-slate-800">
                  {mistake.reason}
                </p>
              </div>
            ))}
          </div>
        </div>

        {/* SECTION 3: INTERACTIVE DIALOGUE CHALLENGE */}
        <div className="p-6 rounded-2xl bg-amber-50/60 dark:bg-amber-950/20 border border-amber-200 dark:border-amber-900/40 space-y-4">
          <div className="flex items-center justify-between">
            <h4 className="text-sm font-bold text-amber-900 dark:text-amber-200 uppercase tracking-wider flex items-center gap-2">
              <Trophy className="w-4 h-4 text-amber-600" />
              <span>3. Spoken Dialogue Challenge</span>
            </h4>
            <span className="text-xs text-amber-700 dark:text-amber-400 font-medium">
              Put it into practice
            </span>
          </div>

          <div className="bg-white dark:bg-slate-900 p-5 rounded-xl border border-amber-200/80 dark:border-amber-900/60 space-y-3">
            <div>
              <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
                Scenario Prompt:
              </span>
              <p className="text-sm font-bold text-slate-900 dark:text-white mt-1">
                {selectedLesson.dialogueChallenge.prompt}
              </p>
            </div>

            <div className="flex items-center gap-2 text-xs text-slate-500 italic">
              <span>💡 Hint: {selectedLesson.dialogueChallenge.hint}</span>
            </div>

            <div className="pt-2 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div className="flex-1">
                <input
                  type="text"
                  value={challengeSpokenText}
                  onChange={(e) => setChallengeSpokenText(e.target.value)}
                  placeholder="Speak your answer with microphone or type here..."
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-xs text-slate-900 dark:text-white"
                />
              </div>

              <div className="flex items-center gap-2 shrink-0">
                <button
                  type="button"
                  onClick={handleRecordChallenge}
                  className={`flex items-center gap-1.5 px-4 py-2.5 rounded-xl text-xs font-bold transition-all ${
                    isRecordingChallenge
                      ? 'bg-red-500 text-white animate-pulse'
                      : 'bg-amber-500 hover:bg-amber-600 text-slate-950'
                  }`}
                >
                  <Mic className="w-4 h-4" />
                  <span>{isRecordingChallenge ? 'Listening...' : 'Speak Response'}</span>
                </button>

                <button
                  type="button"
                  disabled={!challengeSpokenText.trim()}
                  onClick={() => {
                    onIncrementSpeakingMinutes(1);
                    onIncrementSentences();
                    setChallengeResult({
                      score: 95,
                      feedback: "Excellent! Your response sounds natural, courteous, and accurate.",
                    });
                    confetti({ particleCount: 50, spread: 60, origin: { y: 0.6 } });
                  }}
                  className="px-4 py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 dark:bg-slate-100 dark:hover:bg-white text-white dark:text-slate-900 font-bold text-xs disabled:opacity-40 cursor-pointer"
                >
                  Submit
                </button>
              </div>
            </div>

            {challengeResult && (
              <div className="p-4 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 text-emerald-900 dark:text-emerald-200 text-xs space-y-1">
                <div className="flex items-center gap-2 font-bold text-sm">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  <span>Dialogue Passed! Score: {challengeResult.score}/100</span>
                </div>
                <p>{challengeResult.feedback}</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
