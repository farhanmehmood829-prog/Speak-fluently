import React, { useState, useEffect, useRef } from 'react';
import { ChatMessage, Scenario, EnglishLevel, SpeechSettings } from '../types';
import { AppLanguage, TRANSLATIONS, SUPPORTED_LANGUAGES } from '../data/translations';
import { SCENARIOS } from '../data/curriculumData';
import { speakText, stopSpeaking, SpeechRecognizer, isSpeechRecognitionSupported } from '../utils/speech';
import { AudioVisualizer } from './AudioVisualizer';
import {
  Mic,
  MicOff,
  Send,
  Volume2,
  Sparkles,
  AlertCircle,
  CheckCircle2,
  BookOpen,
  RotateCcw,
  VolumeX,
  Globe,
} from 'lucide-react';

interface ConversationTutorProps {
  level: EnglishLevel;
  speechSettings: SpeechSettings;
  onIncrementSpeakingMinutes: (minutes: number) => void;
  onIncrementSentences: () => void;
  language?: AppLanguage;
}

export const ConversationTutor: React.FC<ConversationTutorProps> = ({
  level,
  speechSettings,
  onIncrementSpeakingMinutes,
  onIncrementSentences,
  language = 'en',
}) => {
  const [selectedScenario, setSelectedScenario] = useState<Scenario>(SCENARIOS[0]);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [inputText, setInputText] = useState('');
  const [isListening, setIsListening] = useState(false);
  const [isAITyping, setIsAITyping] = useState(false);
  const [isPlayingAudio, setIsPlayingAudio] = useState<string | null>(null);
  const [autoPlayAudio, setAutoPlayAudio] = useState(true);
  const [translatedMessages, setTranslatedMessages] = useState<Record<string, string>>({});
  const [translatingId, setTranslatingId] = useState<string | null>(null);

  const t = TRANSLATIONS[language] || TRANSLATIONS.en;
  const currentLang = SUPPORTED_LANGUAGES.find((l) => l.code === language) || SUPPORTED_LANGUAGES[0];

  const handleTranslateMessage = async (msgId: string, text: string) => {
    if (translatedMessages[msgId]) {
      // Toggle off if already translated
      setTranslatedMessages((prev) => {
        const copy = { ...prev };
        delete copy[msgId];
        return copy;
      });
      return;
    }

    if (language === 'en') {
      alert('Your app instruction language is currently English. Switch to Urdu/Hindi, Arabic, or Spanish from the top navigation to see translations!');
      return;
    }

    setTranslatingId(msgId);
    try {
      const res = await fetch('/api/translate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text, targetLang: language }),
      });
      const data = await res.json();
      if (data.translation) {
        setTranslatedMessages((prev) => ({ ...prev, [msgId]: data.translation }));
      }
    } catch (e) {
      console.error('Translation error:', e);
    } finally {
      setTranslatingId(null);
    }
  };

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const recognizerRef = useRef<SpeechRecognizer | null>(null);

  // Initialize conversation when scenario changes
  useEffect(() => {
    stopSpeaking();
    const initialMessage: ChatMessage = {
      id: 'init-1',
      sender: 'tutor',
      text: selectedScenario.starterCoachMessage,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      suggestedReplies: selectedScenario.cheatSheet,
      vocabularySpotlight: [
        {
          word: 'welcome',
          meaning: 'kindly received or accepted',
          example: 'You are always welcome here!',
        },
      ],
    };
    setMessages([initialMessage]);

    if (autoPlayAudio) {
      setIsPlayingAudio('init-1');
      speakText(selectedScenario.starterCoachMessage, speechSettings, () => {
        setIsPlayingAudio(null);
      });
    }
  }, [selectedScenario, level]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isAITyping]);

  const handleToggleMic = () => {
    if (isListening) {
      recognizerRef.current?.stop();
      setIsListening(false);
      return;
    }

    if (!isSpeechRecognitionSupported()) {
      alert('Speech Recognition is not supported by your browser. Please type in the text box below.');
      return;
    }

    const recognizer = new SpeechRecognizer(
      (transcript, isFinal) => {
        setInputText(transcript);
        if (isFinal) {
          // If finalized, keep the text ready
        }
      },
      (error) => {
        console.warn('Speech error:', error);
        setIsListening(false);
      },
      (listening) => {
        setIsListening(listening);
      }
    );

    recognizerRef.current = recognizer;
    recognizer.start();
  };

  const handleSendMessage = async (textToSend: string) => {
    const text = textToSend.trim();
    if (!text || isAITyping) return;

    if (isListening) {
      recognizerRef.current?.stop();
      setIsListening(false);
    }

    onIncrementSpeakingMinutes(0.5);
    onIncrementSentences();

    const userMessage: ChatMessage = {
      id: `user-${Date.now()}`,
      sender: 'user',
      text,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    const newHistory = [...messages, userMessage];
    setMessages(newHistory);
    setInputText('');
    setIsAITyping(true);

    try {
      const response = await fetch('/api/chat-tutor', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: text,
          history: newHistory.map((m) => ({ sender: m.sender, text: m.text })),
          scenario: selectedScenario.id,
          level,
        }),
      });

      const data = await response.json();
      const tutorMessageId = `tutor-${Date.now()}`;

      const tutorMessage: ChatMessage = {
        id: tutorMessageId,
        sender: 'tutor',
        text: data.reply || "That's wonderful! Tell me more about that.",
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        grammarCorrection: data.grammarCorrection,
        explanation: data.explanation,
        naturalAlternative: data.naturalAlternative,
        vocabularySpotlight: data.vocabularySpotlight,
        suggestedReplies: data.suggestedReplies,
      };

      setMessages((prev) => [...prev, tutorMessage]);

      if (autoPlayAudio) {
        setIsPlayingAudio(tutorMessageId);
        speakText(tutorMessage.text, speechSettings, () => {
          setIsPlayingAudio(null);
        });
      }
    } catch (e) {
      console.error('Chat tutor error:', e);
    } finally {
      setIsAITyping(false);
    }
  };

  const handlePlayAudio = (messageId: string, text: string) => {
    if (isPlayingAudio === messageId) {
      stopSpeaking();
      setIsPlayingAudio(null);
      return;
    }
    setIsPlayingAudio(messageId);
    speakText(text, speechSettings, () => {
      setIsPlayingAudio(null);
    });
  };

  const handleResetConversation = () => {
    stopSpeaking();
    setIsPlayingAudio(null);
    setMessages([
      {
        id: 'reset-1',
        sender: 'tutor',
        text: selectedScenario.starterCoachMessage,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        suggestedReplies: selectedScenario.cheatSheet,
      },
    ]);
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 max-w-7xl mx-auto">
      {/* LEFT COLUMN: SCENARIO SELECTOR & COACH PROFILE */}
      <div className="lg:col-span-4 space-y-6">
        {/* Tutor Identity Card */}
        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-5 shadow-xs">
          <div className="flex items-center gap-4">
            <img
              src="/src/assets/images/avatar_coach_sarah_1794123684651.jpg"
              alt="Coach Sarah"
              className="w-16 h-16 rounded-2xl object-cover ring-2 ring-amber-500/30 shrink-0"
            />
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-bold text-base text-slate-900 dark:text-white">Coach Sarah</h3>
                <span className="text-[10px] font-semibold uppercase px-2 py-0.5 rounded-full bg-emerald-100 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300">
                  Ready to Speak
                </span>
              </div>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                Native English speaking tutor · Adapting to <span className="font-semibold capitalize text-slate-800 dark:text-slate-200">{level}</span>
              </p>
              <div className="flex items-center gap-2 mt-2">
                <button
                  type="button"
                  onClick={() => setAutoPlayAudio(!autoPlayAudio)}
                  className={`text-[11px] flex items-center gap-1 font-medium px-2 py-0.5 rounded-md transition-colors ${
                    autoPlayAudio
                      ? 'bg-amber-100 dark:bg-amber-950/60 text-amber-800 dark:text-amber-300'
                      : 'bg-slate-100 dark:bg-slate-800 text-slate-500'
                  }`}
                >
                  <Volume2 className="w-3 h-3" />
                  <span>Auto-voice: {autoPlayAudio ? 'ON' : 'OFF'}</span>
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Practice Scenarios List */}
        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-5 shadow-xs">
          <div className="flex items-center justify-between mb-4">
            <h4 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider">
              Real-World Situations
            </h4>
            <span className="text-xs text-slate-500">{SCENARIOS.length} scenarios</span>
          </div>

          <div className="space-y-2">
            {SCENARIOS.map((sc) => {
              const active = selectedScenario.id === sc.id;
              return (
                <button
                  key={sc.id}
                  onClick={() => setSelectedScenario(sc)}
                  className={`w-full text-left p-3 rounded-xl transition-all border cursor-pointer ${
                    active
                      ? 'bg-amber-50/70 dark:bg-amber-950/30 border-amber-300 dark:border-amber-800 shadow-xs'
                      : 'bg-transparent hover:bg-slate-50 dark:hover:bg-slate-800/60 border-transparent text-slate-700 dark:text-slate-300'
                  }`}
                >
                  <div className="flex items-center justify-between gap-2">
                    <span
                      className={`text-sm font-semibold ${
                        active ? 'text-amber-900 dark:text-amber-200' : 'text-slate-800 dark:text-slate-200'
                      }`}
                    >
                      {sc.title}
                    </span>
                    <span className="text-[10px] uppercase font-bold text-slate-400">
                      {sc.level}
                    </span>
                  </div>
                  <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 line-clamp-1">
                    {sc.description}
                  </p>
                </button>
              );
            })}
          </div>
        </div>

        {/* Spoken Cheat Sheet for current scenario */}
        <div className="bg-slate-50 dark:bg-slate-900/60 rounded-2xl border border-slate-200 dark:border-slate-800 p-5">
          <div className="flex items-center gap-1.5 text-xs font-bold text-amber-700 dark:text-amber-400 uppercase tracking-wider mb-2">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Spoken Starter Phrases</span>
          </div>
          <p className="text-xs text-slate-500 dark:text-slate-400 mb-3">
            Click any phrase to say it into the dialogue:
          </p>
          <div className="space-y-2">
            {selectedScenario.cheatSheet.map((phrase, i) => (
              <button
                key={i}
                onClick={() => handleSendMessage(phrase)}
                className="w-full text-left p-2.5 rounded-lg bg-white dark:bg-slate-800 hover:bg-amber-50 dark:hover:bg-amber-950/30 border border-slate-200 dark:border-slate-700 text-xs text-slate-800 dark:text-slate-200 font-medium transition-colors"
              >
                "{phrase}"
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* RIGHT COLUMN: ACTIVE CONVERSATION STAGE */}
      <div className="lg:col-span-8 flex flex-col h-[650px] bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs overflow-hidden">
        {/* Stage Header */}
        <div className="p-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between gap-4 bg-slate-50/50 dark:bg-slate-900/50 shrink-0">
          <div>
            <span className="text-xs font-semibold text-amber-600 dark:text-amber-400">
              Active Roleplay
            </span>
            <h3 className="text-base font-bold text-slate-900 dark:text-white">
              {selectedScenario.title}
            </h3>
          </div>

          <div className="flex items-center gap-2">
            {isPlayingAudio && (
              <AudioVisualizer isActive={true} color="amber" label="Coach speaking" />
            )}
            <button
              onClick={handleResetConversation}
              title="Restart dialogue"
              className="p-2 text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-colors"
            >
              <RotateCcw className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Message Stream */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-6">
          {messages.map((msg) => {
            const isUser = msg.sender === 'user';
            const isAudioActive = isPlayingAudio === msg.id;

            return (
              <div
                key={msg.id}
                className={`flex flex-col ${isUser ? 'items-end' : 'items-start'} space-y-2`}
              >
                <div
                  className={`flex items-start gap-3 max-w-[85%] ${
                    isUser ? 'flex-row-reverse' : 'flex-row'
                  }`}
                >
                  {!isUser && (
                    <img
                      src="/src/assets/images/avatar_coach_sarah_1794123684651.jpg"
                      alt="Sarah"
                      className="w-8 h-8 rounded-full object-cover shrink-0 mt-1"
                    />
                  )}

                  <div
                    className={`rounded-2xl p-4 text-sm leading-relaxed ${
                      isUser
                        ? 'bg-slate-900 text-white dark:bg-amber-500 dark:text-slate-950 rounded-tr-xs'
                        : 'bg-slate-100 dark:bg-slate-800 text-slate-900 dark:text-white rounded-tl-xs'
                    }`}
                  >
                    <p>{msg.text}</p>

                    {/* Bilingual Translation Drawer */}
                    {translatedMessages[msg.id] && (
                      <div className="mt-2.5 pt-2 border-t border-slate-200 dark:border-slate-700/80 text-xs text-amber-900 dark:text-amber-200 font-medium">
                        <span className="text-[10px] font-bold text-slate-500 uppercase block mb-0.5">
                          {currentLang.flag} {currentLang.nativeName} Translation:
                        </span>
                        <p className={currentLang.direction === 'rtl' ? 'text-right' : 'text-left'}>
                          {translatedMessages[msg.id]}
                        </p>
                      </div>
                    )}

                    <div
                      className={`flex items-center justify-between gap-3 mt-2 text-[10px] ${
                        isUser
                          ? 'text-slate-300 dark:text-slate-800'
                          : 'text-slate-400 dark:text-slate-400'
                      }`}
                    >
                      <span>{msg.timestamp}</span>
                      {!isUser && (
                        <div className="flex items-center gap-3">
                          <button
                            type="button"
                            onClick={() => handleTranslateMessage(msg.id, msg.text)}
                            className="flex items-center gap-1 hover:underline cursor-pointer text-slate-500 hover:text-amber-600 dark:hover:text-amber-400 font-semibold"
                          >
                            <Globe className="w-3 h-3" />
                            <span>
                              {translatingId === msg.id
                                ? 'Translating...'
                                : translatedMessages[msg.id]
                                ? 'Hide Translation'
                                : `${currentLang.flag} Translate`}
                            </span>
                          </button>

                          <button
                            type="button"
                            onClick={() => handlePlayAudio(msg.id, msg.text)}
                            className="flex items-center gap-1 hover:underline cursor-pointer"
                          >
                            {isAudioActive ? (
                              <>
                                <VolumeX className="w-3 h-3 text-amber-500" />
                                <span>Stop</span>
                              </>
                            ) : (
                              <>
                                <Volume2 className="w-3 h-3 text-amber-500" />
                                <span>{t.tutor.listen}</span>
                              </>
                            )}
                          </button>
                        </div>
                      )}
                    </div>
                  </div>
                </div>

                {/* Spoken Feedback Cards on Tutor Replies */}
                {!isUser && (msg.grammarCorrection || msg.naturalAlternative || msg.vocabularySpotlight) && (
                  <div className="ml-11 max-w-[85%] space-y-2">
                    {/* Grammar or Spelling Correction */}
                    {msg.grammarCorrection && (
                      <div className="bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-900/40 rounded-xl p-3 text-xs">
                        <div className="flex items-center gap-1.5 text-amber-800 dark:text-amber-300 font-bold mb-1">
                          <AlertCircle className="w-3.5 h-3.5" />
                          <span>Gentle Speech Polish:</span>
                        </div>
                        <p className="text-slate-700 dark:text-slate-300 font-medium">
                          Instead of your previous phrasing, try saying:{' '}
                          <span className="font-bold underline text-amber-900 dark:text-amber-200">
                            "{msg.grammarCorrection}"
                          </span>
                        </p>
                        {msg.explanation && (
                          <p className="text-slate-500 dark:text-slate-400 mt-1 italic">
                            💡 {msg.explanation}
                          </p>
                        )}
                      </div>
                    )}

                    {/* How a Native Says It */}
                    {msg.naturalAlternative && (
                      <div className="bg-emerald-50 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-800 rounded-xl p-3 text-xs">
                        <div className="flex items-center gap-1.5 text-emerald-800 dark:text-emerald-300 font-bold mb-1">
                          <CheckCircle2 className="w-3.5 h-3.5" />
                          <span>How an Everyday Native Speaker Expresses This:</span>
                        </div>
                        <p className="text-slate-800 dark:text-slate-200 font-medium">
                          "{msg.naturalAlternative}"
                        </p>
                      </div>
                    )}

                    {/* Quick suggested follow-up phrases */}
                    {msg.suggestedReplies && msg.suggestedReplies.length > 0 && (
                      <div className="flex flex-wrap items-center gap-2 pt-1">
                        <span className="text-[10px] text-slate-400 font-semibold uppercase">
                          Quick Replies:
                        </span>
                        {msg.suggestedReplies.map((reply, i) => (
                          <button
                            key={i}
                            type="button"
                            onClick={() => handleSendMessage(reply)}
                            className="text-xs px-2.5 py-1 rounded-full bg-slate-100 hover:bg-amber-100 dark:bg-slate-800 dark:hover:bg-amber-950/60 text-slate-700 dark:text-slate-300 hover:text-amber-900 dark:hover:text-amber-200 transition-colors"
                          >
                            "{reply}"
                          </button>
                        ))}
                      </div>
                    )}
                  </div>
                )}
              </div>
            );
          })}

          {isAITyping && (
            <div className="flex items-center gap-3">
              <img
                src="/src/assets/images/avatar_coach_sarah_1794123684651.jpg"
                alt="Sarah"
                className="w-8 h-8 rounded-full object-cover"
              />
              <div className="bg-slate-100 dark:bg-slate-800 rounded-2xl p-4 text-xs text-slate-500 flex items-center gap-2">
                <div className="flex items-center gap-1">
                  <div className="w-2 h-2 rounded-full bg-amber-500 animate-bounce" />
                  <div className="w-2 h-2 rounded-full bg-amber-500 animate-bounce [animation-delay:0.2s]" />
                  <div className="w-2 h-2 rounded-full bg-amber-500 animate-bounce [animation-delay:0.4s]" />
                </div>
                <span>Coach Sarah is listening and formulating feedback...</span>
              </div>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Input Bar */}
        <div className="p-4 border-t border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shrink-0">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSendMessage(inputText);
            }}
            className="flex items-center gap-2"
          >
            <button
              type="button"
              onClick={handleToggleMic}
              aria-label="Microphone speaking button"
              className={`p-3 rounded-xl transition-all cursor-pointer ${
                isListening
                  ? 'bg-red-500 text-white animate-pulse shadow-md ring-4 ring-red-500/20'
                  : 'bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold'
              }`}
            >
              {isListening ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
            </button>

            <div className="flex-1 relative">
              <input
                type="text"
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                placeholder={
                  isListening
                    ? 'Listening to your speech... Speak clearly in English!'
                    : 'Speak into mic or type your answer here...'
                }
                className="w-full px-4 py-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white placeholder:text-slate-400 text-sm focus:outline-hidden focus:ring-2 focus:ring-amber-500"
              />
              {isListening && (
                <div className="absolute right-3 top-1/2 -translate-y-1/2">
                  <AudioVisualizer isActive={true} color="emerald" />
                </div>
              )}
            </div>

            <button
              type="submit"
              disabled={!inputText.trim() || isAITyping}
              className="p-3 bg-slate-900 hover:bg-slate-800 dark:bg-slate-100 dark:hover:bg-white text-white dark:text-slate-900 rounded-xl transition-colors disabled:opacity-40 cursor-pointer"
            >
              <Send className="w-5 h-5" />
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};
