import React, { useState } from 'react';
import { SubscriptionPlan } from '../types';
import {
  X,
  Check,
  Crown,
  Sparkles,
  Lock,
  Unlock,
  ShieldCheck,
  Star,
  Award,
  Zap,
} from 'lucide-react';
import confetti from 'canvas-confetti';

interface PremiumSubscriptionModalProps {
  isOpen: boolean;
  onClose: () => void;
  isPremium: boolean;
  onUpgrade: (plan: SubscriptionPlan) => void;
  onToggleMockPremium: () => void;
}

export const PremiumSubscriptionModal: React.FC<PremiumSubscriptionModalProps> = ({
  isOpen,
  onClose,
  isPremium,
  onUpgrade,
  onToggleMockPremium,
}) => {
  const [selectedPlan, setSelectedPlan] = useState<SubscriptionPlan>('quarterly');
  const [promoCode, setPromoCode] = useState('');
  const [discountApplied, setDiscountApplied] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);

  if (!isOpen) return null;

  const handleApplyPromo = (e: React.FormEvent) => {
    e.preventDefault();
    const clean = promoCode.trim().toUpperCase();
    if (clean === 'IELTS2026' || clean === 'BAND9' || clean === 'PREMIUM') {
      setDiscountApplied(true);
      confetti({ particleCount: 30, spread: 45, origin: { y: 0.6 } });
    } else {
      alert('Invalid code. Try using code "IELTS2026" for a 20% discount!');
    }
  };

  const handleCompleteUpgrade = () => {
    setIsProcessing(true);
    setTimeout(() => {
      setIsProcessing(false);
      onUpgrade(selectedPlan);
      confetti({ particleCount: 80, spread: 70, origin: { y: 0.5 } });
      onClose();
    }, 600);
  };

  const plans = [
    {
      id: 'monthly' as SubscriptionPlan,
      name: '1-Month Sprint',
      price: discountApplied ? '$11.99' : '$14.99',
      originalPrice: '$19.99',
      billing: 'Billed monthly',
      badge: null,
      desc: 'Ideal for quick 30-day exam preparation before test day.',
    },
    {
      id: 'quarterly' as SubscriptionPlan,
      name: '3-Month Intensive',
      price: discountApplied ? '$23.99' : '$29.99',
      originalPrice: '$44.99',
      billing: '$9.99 / month · Save 50%',
      badge: 'Most Popular',
      desc: 'Recommended by official IELTS tutors to jump +1.5 band score.',
    },
    {
      id: 'lifetime' as SubscriptionPlan,
      name: 'Lifetime Mastery',
      price: discountApplied ? '$39.99' : '$49.99',
      originalPrice: '$89.99',
      billing: 'One-time payment forever',
      badge: 'Best Value',
      desc: 'Full access to all current and future 2026-2027 IELTS test sets.',
    },
  ];

  const featuresComparison = [
    { feature: 'Official Part 1, 2, and 3 Mock Test Flow', free: true, pro: true },
    { feature: 'Audio Recording & 1-min / 2-min Countdown Timers', free: true, pro: true },
    { feature: 'Instant AI Band Score Evaluation (4 Criteria)', free: '1 Test Only', pro: 'Unlimited' },
    { feature: 'Full Cambridge & British Council Advanced Test Sets', free: false, pro: true },
    { feature: 'Band 9.0 Model Transcripts & High-Register Vocabulary', free: false, pro: true },
    { feature: 'Examiner Detailed Diagnostic Audio Feedback', free: false, pro: true },
    { feature: 'Cue Card Master Question Bank (120+ Topics)', free: false, pro: true },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs overflow-y-auto">
      <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-2xl max-w-2xl w-full p-6 sm:p-8 my-8 relative overflow-hidden">
        {/* Subtle decorative glow */}
        <div className="absolute top-0 right-0 w-64 h-64 bg-amber-500/10 rounded-full blur-3xl pointer-events-none -mr-20 -mt-20" />

        {/* Modal Header */}
        <div className="flex items-start justify-between gap-4 pb-6 border-b border-slate-100 dark:border-slate-800 relative z-10">
          <div className="flex items-center gap-3">
            <div className="relative shrink-0">
              <img
                src="/src/assets/images/app_icon_speakfluent_1794130126869.jpg"
                alt="SpeakFluent Pro"
                className="w-14 h-14 rounded-2xl object-cover shadow-md ring-2 ring-amber-500/50"
              />
              <div className="absolute -bottom-1 -right-1 w-6 h-6 rounded-full bg-amber-500 flex items-center justify-center text-slate-950 shadow-xs">
                <Crown className="w-3.5 h-3.5 fill-slate-950" />
              </div>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-extrabold uppercase tracking-wider px-2 py-0.5 rounded-full bg-amber-100 dark:bg-amber-950/60 text-amber-800 dark:text-amber-300">
                  IELTS Pro Pass
                </span>
                {isPremium && (
                  <span className="text-xs font-bold text-emerald-600 dark:text-emerald-400 flex items-center gap-1">
                    <Check className="w-3.5 h-3.5" />
                    <span>Unlocked</span>
                  </span>
                )}
              </div>
              <h3 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white mt-1">
                Unlock Advanced IELTS Speaking & Band 9.0 Analysis
              </h3>
            </div>
          </div>

          <button
            onClick={onClose}
            aria-label="Close modal"
            className="p-2 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 rounded-xl"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Status indicator if already unlocked */}
        {isPremium && (
          <div className="my-5 p-4 rounded-2xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 flex items-center justify-between gap-4">
            <div className="flex items-center gap-2.5">
              <ShieldCheck className="w-5 h-5 text-emerald-600 dark:text-emerald-400 shrink-0" />
              <div>
                <p className="text-xs font-bold text-emerald-900 dark:text-emerald-200">
                  You are currently a Premium IELTS Pro Member!
                </p>
                <p className="text-[11px] text-emerald-700 dark:text-emerald-400">
                  All tests, cue cards, and diagnostic band evaluations are unlocked.
                </p>
              </div>
            </div>
            <button
              onClick={onToggleMockPremium}
              className="text-xs font-semibold px-3 py-1.5 rounded-lg bg-emerald-200/80 hover:bg-emerald-300 dark:bg-emerald-800 text-emerald-900 dark:text-emerald-100 transition-colors whitespace-nowrap shrink-0"
            >
              Test as Locked User
            </button>
          </div>
        )}

        {/* Pricing Tiers */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 my-6">
          {plans.map((p) => {
            const isSelected = selectedPlan === p.id;
            return (
              <div
                key={p.id}
                onClick={() => setSelectedPlan(p.id)}
                className={`relative p-5 rounded-2xl border transition-all cursor-pointer flex flex-col justify-between ${
                  isSelected
                    ? 'border-amber-500 dark:border-amber-400 ring-2 ring-amber-500/20 bg-amber-50/40 dark:bg-amber-950/20 shadow-xs'
                    : 'border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 hover:border-slate-300'
                }`}
              >
                {p.badge && (
                  <span className="absolute -top-2.5 right-4 px-2 py-0.5 rounded-full text-[10px] font-extrabold uppercase tracking-wide bg-amber-500 text-slate-950 shadow-xs">
                    {p.badge}
                  </span>
                )}

                <div>
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-xs font-bold text-slate-900 dark:text-white">
                      {p.name}
                    </span>
                    <div
                      className={`w-4 h-4 rounded-full border flex items-center justify-center ${
                        isSelected
                          ? 'border-amber-500 bg-amber-500 text-slate-950'
                          : 'border-slate-300 dark:border-slate-700'
                      }`}
                    >
                      {isSelected && <Check className="w-2.5 h-2.5 stroke-[3]" />}
                    </div>
                  </div>

                  <div className="mt-2 flex items-baseline gap-1.5">
                    <span className="text-2xl font-black text-slate-900 dark:text-white">
                      {p.price}
                    </span>
                    <span className="text-xs text-slate-400 line-through">
                      {p.originalPrice}
                    </span>
                  </div>
                  <div className="text-[11px] font-semibold text-amber-700 dark:text-amber-400 mt-0.5">
                    {p.billing}
                  </div>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-2 leading-relaxed">
                    {p.desc}
                  </p>
                </div>
              </div>
            );
          })}
        </div>

        {/* Feature Comparison Table */}
        <div className="my-6 bg-slate-50 dark:bg-slate-950/60 rounded-2xl border border-slate-200/80 dark:border-slate-800 p-4 sm:p-5">
          <h4 className="text-xs font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider mb-3">
            What is Included in IELTS Pro Pass:
          </h4>
          <div className="space-y-2.5">
            {featuresComparison.map((item, idx) => (
              <div
                key={idx}
                className="flex items-center justify-between gap-4 text-xs py-1 border-b border-slate-100 dark:border-slate-800/80 last:border-0"
              >
                <span className="text-slate-700 dark:text-slate-300 font-medium">
                  {item.feature}
                </span>
                <div className="flex items-center gap-4 shrink-0">
                  <span className="text-[11px] text-slate-400">
                    {typeof item.free === 'boolean' ? (item.free ? 'Free' : '—') : item.free}
                  </span>
                  <span className="text-emerald-600 dark:text-emerald-400 font-bold flex items-center gap-1">
                    <Check className="w-3.5 h-3.5" />
                    <span>{typeof item.pro === 'boolean' ? 'Included' : item.pro}</span>
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Promo Code Input */}
        <form onSubmit={handleApplyPromo} className="flex gap-2 my-5">
          <input
            type="text"
            value={promoCode}
            onChange={(e) => setPromoCode(e.target.value)}
            placeholder="Discount code (try: IELTS2026)"
            className="flex-1 px-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-xs font-mono uppercase text-slate-900 dark:text-white"
          />
          <button
            type="submit"
            className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 font-bold text-xs rounded-xl transition-colors cursor-pointer"
          >
            Apply Code
          </button>
        </form>

        {discountApplied && (
          <p className="text-xs text-emerald-600 dark:text-emerald-400 font-semibold mb-4">
            🎉 20% discount applied to all passes!
          </p>
        )}

        {/* Action Button */}
        <div className="pt-2 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="text-[11px] text-slate-500">
            🔒 Instant access · Simulated risk-free upgrade · 100% testable
          </div>

          <div className="flex items-center gap-2 w-full sm:w-auto">
            <button
              onClick={onClose}
              className="px-4 py-3 rounded-xl border border-slate-200 dark:border-slate-700 text-xs font-semibold text-slate-700 dark:text-slate-300 hover:bg-slate-50"
            >
              Cancel
            </button>
            <button
              onClick={handleCompleteUpgrade}
              disabled={isProcessing}
              className="flex-1 sm:flex-initial flex items-center justify-center gap-2 px-6 py-3 bg-amber-500 hover:bg-amber-600 text-slate-950 font-black text-xs rounded-xl shadow-md transition-transform active:scale-95 disabled:opacity-50 cursor-pointer"
            >
              {isProcessing ? (
                <span>Activating Pro Pass...</span>
              ) : (
                <>
                  <Zap className="w-4 h-4 fill-slate-950" />
                  <span>
                    {isPremium ? 'Renew / Update Pass' : 'Unlock All IELTS Tests'}
                  </span>
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
