import React, { useState } from 'react';
import { EnglishLevel, SpeechSettings } from '../types';
import { SPELLING_WORDS, HOMOPHONE_PAIRS, SILENT_LETTER_RULES, SpellingWord } from '../data/curriculumData';
import { speakText, stopSpeaking, SpeechRecognizer, isSpeechRecognitionSupported } from '../utils/speech';
import { AudioVisualizer } from './AudioVisualizer';
import {
  CheckCircle2,
  AlertCircle,
  Volume2,
  Mic,
  MicOff,
  Sparkles,
  ArrowRight,
  BookOpen,
  HelpCircle,
  Trophy,
  RotateCcw,
  VolumeX,
} from 'lucide-react';
import confetti from 'canvas-confetti';

interface SpellingDoctorProps {
  level: EnglishLevel;
  speechSettings: SpeechSettings;
  onIncrementSpeakingMinutes: (minutes: number) => void;
  onIncrementSentences: () => void;
}

export const SpellingDoctor: React.FC<SpellingDoctorProps> = ({
  level,
  speechSettings,
  onIncrementSpeakingMinutes,
  onIncrementSentences,
}) => {
  const [activeSubTab, setActiveSubTab] = useState<'checker' | 'bee' | 'homophones' | 'silent'>('checker');

  // Checker state
  const [inputText, setInputText] = useState('I am definately going to recieve there letter tommorrow becuase we are good freinds.');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisResult, setAnalysisResult] = useState<any>(null);
  const [isListening, setIsListening] = useState(false);
  const [isPlayingAudio, setIsPlayingAudio] = useState(false);

  // Spelling Bee State
  const filteredWords = SPELLING_WORDS.filter((w) => w.level === level);
  const [currentWordIndex, setCurrentWordIndex] = useState(0);
  const [userSpellingInput, setUserSpellingInput] = useState('');
  const [beeResultState, setBeeResultState] = useState<'idle' | 'correct' | 'incorrect'>('idle');
  const [score, setScore] = useState(0);
  const [attempts, setAttempts] = useState(0);

  // Homophone quiz state
  const currentHomophones = HOMOPHONE_PAIRS.filter((h) => h.level === level || level === 'advanced');
  const [homophoneIndex, setHomophoneIndex] = useState(0);
  const [selectedHomoAnswer, setSelectedHomoAnswer] = useState<string | null>(null);
  const [homoSubmitted, setHomoSubmitted] = useState(false);

  // Speech recognizer setup for checker
  const handleStartMic = () => {
    if (!isSpeechRecognitionSupported()) {
      alert('Speech recognition is not supported in this browser. Please type your sentence or use Chrome.');
      return;
    }
    const recognizer = new SpeechRecognizer(
      (transcript) => {
        setInputText(transcript);
      },
      (error) => {
        console.warn('Mic error:', error);
        setIsListening(false);
      },
      (listening) => {
        setIsListening(listening);
        if (!listening) {
          onIncrementSpeakingMinutes(0.5);
          onIncrementSentences();
        }
      }
    );
    recognizer.start();
  };

  const handleAnalyzeText = async () => {
    if (!inputText.trim()) return;
    setIsAnalyzing(true);
    setAnalysisResult(null);

    try {
      const response = await fetch('/api/check-spelling-grammar', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text: inputText, level }),
      });
      const data = await response.json();
      setAnalysisResult(data);
      if (!data.hasErrors && data.spellingIssues?.length === 0) {
        confetti({ particleCount: 50, spread: 60, origin: { y: 0.6 } });
      }
    } catch (e) {
      console.error('Spelling analysis error:', e);
    } finally {
      setIsAnalyzing(false);
    }
  };

  const handlePlayVoice = (textToSpeak: string) => {
    if (isPlayingAudio) {
      stopSpeaking();
      setIsPlayingAudio(false);
      return;
    }
    setIsPlayingAudio(true);
    speakText(textToSpeak, speechSettings, () => {
      setIsPlayingAudio(false);
    });
  };

  // Spelling Bee Handlers
  const currentWord: SpellingWord | undefined = filteredWords[currentWordIndex] || filteredWords[0];

  const handlePlayBeeWord = () => {
    if (!currentWord) return;
    speakText(`${currentWord.word}. ... Example sentence: ${currentWord.exampleSentence}. ... ${currentWord.word}.`, speechSettings);
  };

  const handleCheckSpelling = (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentWord || !userSpellingInput.trim()) return;

    const isMatch = userSpellingInput.trim().toLowerCase() === currentWord.word.toLowerCase();
    setAttempts((prev) => prev + 1);

    if (isMatch) {
      setBeeResultState('correct');
      setScore((prev) => prev + 1);
      confetti({ particleCount: 40, spread: 50, origin: { y: 0.7 } });
    } else {
      setBeeResultState('incorrect');
    }
  };

  const handleNextBeeWord = () => {
    setUserSpellingInput('');
    setBeeResultState('idle');
    if (currentWordIndex < filteredWords.length - 1) {
      setCurrentWordIndex((prev) => prev + 1);
    } else {
      setCurrentWordIndex(0);
    }
  };

  const currentHomoItem = currentHomophones[homophoneIndex] || currentHomophones[0];

  return (
    <div className="space-y-8 max-w-5xl mx-auto">
      {/* Header Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-6 border-b border-slate-200 dark:border-slate-800">
        <div>
          <div className="flex items-center gap-2 text-xs font-semibold text-amber-600 dark:text-amber-400 mb-1">
            <Sparkles className="w-4 h-4" />
            <span>Spelling & Grammar Doctor · {level.toUpperCase()} LEVEL</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-slate-900 dark:text-white">
            Fix Spelling & Speak Like a Native
          </h2>
          <p className="mt-1 text-sm text-slate-600 dark:text-slate-400 max-w-2xl">
            Never second-guess tricky words like <span className="font-semibold text-slate-800 dark:text-slate-200">"definitely"</span>, <span className="font-semibold text-slate-800 dark:text-slate-200">"separate"</span>, or confusing homophones. Instant corrections with authentic pronunciation rules.
          </p>
        </div>

        {/* Sub-tab switcher */}
        <div className="flex items-center gap-1 p-1 bg-slate-100 dark:bg-slate-800 rounded-xl text-xs font-medium shrink-0 self-start md:self-center">
          <button
            onClick={() => setActiveSubTab('checker')}
            className={`px-3 py-1.5 rounded-lg transition-colors whitespace-nowrap shrink-0 ${
              activeSubTab === 'checker'
                ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-xs font-semibold'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            Spelling Corrector
          </button>
          <button
            onClick={() => setActiveSubTab('bee')}
            className={`px-3 py-1.5 rounded-lg transition-colors whitespace-nowrap shrink-0 ${
              activeSubTab === 'bee'
                ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-xs font-semibold'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            Spelling Bee Quiz
          </button>
          <button
            onClick={() => setActiveSubTab('homophones')}
            className={`px-3 py-1.5 rounded-lg transition-colors whitespace-nowrap shrink-0 ${
              activeSubTab === 'homophones'
                ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-xs font-semibold'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            Confusing Homophones
          </button>
          <button
            onClick={() => setActiveSubTab('silent')}
            className={`px-3 py-1.5 rounded-lg transition-colors whitespace-nowrap shrink-0 ${
              activeSubTab === 'silent'
                ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-xs font-semibold'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            Silent Letters Guide
          </button>
        </div>
      </div>

      {/* SUB-TAB 1: LIVE SPELLING & GRAMMAR CHECKER */}
      {activeSubTab === 'checker' && (
        <div className="space-y-6">
          <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 shadow-xs">
            <div className="flex items-center justify-between gap-4 mb-3">
              <label htmlFor="sentence-input" className="text-sm font-semibold text-slate-900 dark:text-slate-100">
                Write or speak any English sentence to inspect:
              </label>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={handleStartMic}
                  className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg transition-colors ${
                    isListening
                      ? 'bg-red-50 text-red-600 dark:bg-red-950/40 dark:text-red-400 border border-red-200 animate-pulse'
                      : 'bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300'
                  }`}
                >
                  {isListening ? <MicOff className="w-3.5 h-3.5" /> : <Mic className="w-3.5 h-3.5 text-amber-600" />}
                  <span>{isListening ? 'Listening...' : 'Speak into Mic'}</span>
                </button>
              </div>
            </div>

            <textarea
              id="sentence-input"
              rows={3}
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              placeholder="e.g., I am definately going to recieve there invitation tommorrow..."
              className="w-full p-4 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50/50 dark:bg-slate-950/50 text-slate-900 dark:text-white focus:outline-hidden focus:ring-2 focus:ring-amber-500/50 text-base font-normal leading-relaxed resize-none"
            />

            <div className="mt-4 flex flex-wrap items-center justify-between gap-3">
              <div className="flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400">
                <span>Try sample:</span>
                <button
                  type="button"
                  onClick={() =>
                    setInputText(
                      'She said that accomodation was not neccessary untill we recieve there confirmation.'
                    )
                  }
                  className="hover:underline text-amber-600 dark:text-amber-400"
                >
                  "Hotel accommodation..."
                </button>
                <span>·</span>
                <button
                  type="button"
                  onClick={() =>
                    setInputText(
                      'I am agree with you and I will seperate the papers tommorrow.'
                    )
                  }
                  className="hover:underline text-amber-600 dark:text-amber-400"
                >
                  "I am agree..."
                </button>
              </div>

              <button
                type="button"
                disabled={isAnalyzing || !inputText.trim()}
                onClick={handleAnalyzeText}
                className="flex items-center gap-2 px-5 py-2.5 bg-slate-900 hover:bg-slate-800 dark:bg-amber-500 dark:hover:bg-amber-600 text-white dark:text-slate-950 font-semibold text-sm rounded-xl transition-all shadow-xs disabled:opacity-50 cursor-pointer"
              >
                {isAnalyzing ? (
                  <>
                    <div className="w-4 h-4 border-2 border-white dark:border-slate-900 border-t-transparent rounded-full animate-spin" />
                    <span>Analyzing Spelling & Grammar...</span>
                  </>
                ) : (
                  <>
                    <Sparkles className="w-4 h-4" />
                    <span>Check & Correct Now</span>
                  </>
                )}
              </button>
            </div>
          </div>

          {/* Analysis Results View */}
          {analysisResult && (
            <div className="space-y-5 animate-in fade-in duration-300">
              {/* Spelling Issues Caught */}
              {analysisResult.spellingIssues && analysisResult.spellingIssues.length > 0 ? (
                <div className="bg-amber-50/70 dark:bg-amber-950/20 border border-amber-200 dark:border-amber-900/60 rounded-2xl p-6">
                  <div className="flex items-center gap-2 text-amber-800 dark:text-amber-300 font-bold text-sm mb-4">
                    <AlertCircle className="w-5 h-5 text-amber-600" />
                    <span>
                      {analysisResult.spellingIssues.length} Spelling Slip
                      {analysisResult.spellingIssues.length > 1 ? 's' : ''} Identified
                    </span>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {analysisResult.spellingIssues.map((issue: any, idx: number) => (
                      <div
                        key={idx}
                        className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-amber-200/60 dark:border-amber-900/40 shadow-xs flex flex-col justify-between"
                      >
                        <div>
                          <div className="flex items-center justify-between gap-2 mb-2">
                            <span className="line-through text-red-500 dark:text-red-400 font-semibold text-sm">
                              {issue.word}
                            </span>
                            <ArrowRight className="w-4 h-4 text-slate-400" />
                            <span className="text-emerald-600 dark:text-emerald-400 font-extrabold text-base">
                              {issue.correction}
                            </span>
                            <button
                              onClick={() => handlePlayVoice(issue.correction)}
                              title="Listen to pronunciation"
                              className="p-1 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-md text-slate-600 dark:text-slate-300"
                            >
                              <Volume2 className="w-4 h-4" />
                            </button>
                          </div>
                          <div className="text-xs text-slate-500 dark:text-slate-400 font-mono mb-2">
                            {issue.phonetic}
                          </div>
                          <p className="text-xs text-slate-700 dark:text-slate-300 leading-relaxed">
                            💡 <span className="font-semibold">Memory Rule:</span> {issue.rule}
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              ) : (
                <div className="p-4 rounded-xl bg-emerald-50 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-800 text-emerald-800 dark:text-emerald-300 text-sm flex items-center gap-2 font-medium">
                  <CheckCircle2 className="w-5 h-5 text-emerald-600 dark:text-emerald-400 shrink-0" />
                  <span>Flawless spelling! No misspelled words were detected in your text.</span>
                </div>
              )}

              {/* Three-Tier Polished Versions */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {/* 1. Corrected Standard */}
                <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-5 flex flex-col justify-between shadow-xs">
                  <div>
                    <div className="flex items-center justify-between gap-2 mb-2">
                      <span className="text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
                        1. Corrected Standard
                      </span>
                      <button
                        onClick={() => handlePlayVoice(analysisResult.correctedText)}
                        className="p-1 text-slate-500 hover:text-slate-900 dark:hover:text-white"
                        title="Listen"
                      >
                        <Volume2 className="w-4 h-4" />
                      </button>
                    </div>
                    <p className="text-sm text-slate-800 dark:text-slate-200 font-medium leading-relaxed">
                      "{analysisResult.correctedText}"
                    </p>
                  </div>
                  <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800 text-[11px] text-slate-500">
                    Clean, grammatically sound English with accurate spelling.
                  </div>
                </div>

                {/* 2. Casual Spoken Native */}
                <div className="bg-white dark:bg-slate-900 rounded-2xl border border-amber-200 dark:border-amber-900/60 p-5 flex flex-col justify-between shadow-xs ring-1 ring-amber-500/10">
                  <div>
                    <div className="flex items-center justify-between gap-2 mb-2">
                      <span className="text-xs font-semibold text-amber-700 dark:text-amber-400 uppercase tracking-wider">
                        2. Casual Native Spoken
                      </span>
                      <button
                        onClick={() => handlePlayVoice(analysisResult.casualNativeVersion)}
                        className="p-1 text-amber-700 hover:text-amber-900 dark:text-amber-400"
                        title="Listen to native casual phrasing"
                      >
                        <Volume2 className="w-4 h-4" />
                      </button>
                    </div>
                    <p className="text-sm text-slate-900 dark:text-white font-medium leading-relaxed">
                      "{analysisResult.casualNativeVersion}"
                    </p>
                  </div>
                  <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800 text-[11px] text-amber-700/80 dark:text-amber-400/80 font-medium">
                    How native speakers talk with friends and peers.
                  </div>
                </div>

                {/* 3. Professional Workplace */}
                <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-5 flex flex-col justify-between shadow-xs">
                  <div>
                    <div className="flex items-center justify-between gap-2 mb-2">
                      <span className="text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
                        3. Professional Workplace
                      </span>
                      <button
                        onClick={() => handlePlayVoice(analysisResult.professionalVersion)}
                        className="p-1 text-slate-500 hover:text-slate-900 dark:hover:text-white"
                        title="Listen"
                      >
                        <Volume2 className="w-4 h-4" />
                      </button>
                    </div>
                    <p className="text-sm text-slate-800 dark:text-slate-200 font-medium leading-relaxed">
                      "{analysisResult.professionalVersion}"
                    </p>
                  </div>
                  <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800 text-[11px] text-slate-500">
                    Polite, precise, ideal for business emails and presentations.
                  </div>
                </div>
              </div>

              {/* Key Takeaways */}
              {analysisResult.keyTakeaways && analysisResult.keyTakeaways.length > 0 && (
                <div className="bg-slate-50 dark:bg-slate-950 p-4 rounded-xl border border-slate-200 dark:border-slate-800">
                  <h4 className="text-xs font-semibold text-slate-700 dark:text-slate-300 uppercase tracking-wider mb-2">
                    Linguistic Takeaways for {level} level:
                  </h4>
                  <ul className="space-y-1.5 text-xs text-slate-600 dark:text-slate-400">
                    {analysisResult.keyTakeaways.map((tip: string, i: number) => (
                      <li key={i} className="flex items-start gap-2">
                        <span className="text-amber-500 font-bold">•</span>
                        <span>{tip}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          )}
        </div>
      )}

      {/* SUB-TAB 2: SPELLING BEE QUIZ */}
      {activeSubTab === 'bee' && currentWord && (
        <div className="space-y-6">
          <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 sm:p-8 shadow-xs">
            <div className="flex items-center justify-between gap-4 mb-6">
              <div>
                <span className="text-xs font-semibold text-amber-600 dark:text-amber-400">
                  Word {currentWordIndex + 1} of {filteredWords.length} · {level.toUpperCase()}
                </span>
                <h3 className="text-xl font-bold text-slate-900 dark:text-white">
                  Listen & Spell the English Word
                </h3>
              </div>
              <div className="flex items-center gap-2 text-xs font-semibold px-3 py-1.5 bg-slate-100 dark:bg-slate-800 rounded-lg text-slate-700 dark:text-slate-300">
                <Trophy className="w-4 h-4 text-amber-500" />
                <span>
                  Score: {score}/{attempts}
                </span>
              </div>
            </div>

            {/* Audio Playback Zone */}
            <div className="bg-slate-50 dark:bg-slate-950 rounded-2xl p-6 border border-slate-200/80 dark:border-slate-800 text-center space-y-4">
              <p className="text-xs text-slate-500 dark:text-slate-400 font-medium">
                Click below to hear the target word and sample context:
              </p>
              <button
                type="button"
                onClick={handlePlayBeeWord}
                className="inline-flex items-center gap-3 px-6 py-3.5 bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold text-sm rounded-xl transition-transform active:scale-95 shadow-xs cursor-pointer"
              >
                <Volume2 className="w-5 h-5" />
                <span>Listen to Word & Example</span>
              </button>

              <div className="pt-2 text-xs text-slate-500 dark:text-slate-400">
                <span>Definition: </span>
                <span className="italic text-slate-700 dark:text-slate-300">
                  "{currentWord.definition}"
                </span>
              </div>
            </div>

            {/* Input Form */}
            <form onSubmit={handleCheckSpelling} className="mt-6 space-y-4">
              <label htmlFor="bee-input" className="block text-xs font-semibold text-slate-700 dark:text-slate-300">
                Type the exact spelling here:
              </label>
              <div className="flex flex-col sm:flex-row gap-3">
                <input
                  id="bee-input"
                  type="text"
                  autoFocus
                  autoComplete="off"
                  value={userSpellingInput}
                  onChange={(e) => setUserSpellingInput(e.target.value)}
                  placeholder="e.g. type your spelling here..."
                  className="flex-1 px-4 py-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-slate-900 dark:text-white font-mono text-base focus:outline-hidden focus:ring-2 focus:ring-amber-500"
                />
                <button
                  type="submit"
                  disabled={!userSpellingInput.trim()}
                  className="px-6 py-3 bg-slate-900 hover:bg-slate-800 dark:bg-slate-100 dark:hover:bg-white text-white dark:text-slate-900 font-bold text-sm rounded-xl transition-colors disabled:opacity-50 cursor-pointer"
                >
                  Verify Spelling
                </button>
              </div>
            </form>

            {/* Result Feedback Banner */}
            {beeResultState !== 'idle' && (
              <div
                className={`mt-6 p-5 rounded-xl border transition-all ${
                  beeResultState === 'correct'
                    ? 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-200 dark:border-emerald-800 text-emerald-900 dark:text-emerald-200'
                    : 'bg-red-50 dark:bg-red-950/40 border-red-200 dark:border-red-800 text-red-900 dark:text-red-200'
                }`}
              >
                <div className="flex items-start justify-between gap-4">
                  <div className="space-y-2">
                    <div className="flex items-center gap-2 font-bold text-base">
                      {beeResultState === 'correct' ? (
                        <>
                          <CheckCircle2 className="w-5 h-5 text-emerald-600" />
                          <span>Spot on! Correct spelling: {currentWord.word}</span>
                        </>
                      ) : (
                        <>
                          <AlertCircle className="w-5 h-5 text-red-600" />
                          <span>
                            Common mistake: <span className="line-through">{userSpellingInput}</span> → Correct:{' '}
                            <span className="font-extrabold underline">{currentWord.word}</span>
                          </span>
                        </>
                      )}
                    </div>
                    <div className="text-xs text-slate-600 dark:text-slate-300">
                      <span className="font-semibold">IPA:</span>{' '}
                      <span className="font-mono">{currentWord.phonetic}</span>
                    </div>
                    <div className="text-xs text-slate-700 dark:text-slate-300">
                      💡 <span className="font-semibold">Mnemonic Memory Trick:</span>{' '}
                      {currentWord.mnemonicRule}
                    </div>
                  </div>

                  <button
                    onClick={handleNextBeeWord}
                    className="px-4 py-2 bg-slate-900 dark:bg-white text-white dark:text-slate-900 font-semibold text-xs rounded-lg hover:opacity-90 transition-opacity whitespace-nowrap shrink-0"
                  >
                    Next Word →
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* SUB-TAB 3: CONFUSING HOMOPHONES */}
      {activeSubTab === 'homophones' && currentHomoItem && (
        <div className="space-y-6">
          <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 sm:p-8 shadow-xs">
            <div className="flex items-center justify-between gap-4 mb-4">
              <div className="flex items-center gap-2">
                <span className="text-xs font-semibold text-amber-600 dark:text-amber-400">
                  Homophone Pair {homophoneIndex + 1} of {currentHomophones.length}
                </span>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => {
                    setHomoSubmitted(false);
                    setSelectedHomoAnswer(null);
                    setHomophoneIndex((prev) => (prev > 0 ? prev - 1 : currentHomophones.length - 1));
                  }}
                  className="px-3 py-1 text-xs font-medium rounded-lg bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300"
                >
                  Previous
                </button>
                <button
                  onClick={() => {
                    setHomoSubmitted(false);
                    setSelectedHomoAnswer(null);
                    setHomophoneIndex((prev) => (prev < currentHomophones.length - 1 ? prev + 1 : 0));
                  }}
                  className="px-3 py-1 text-xs font-medium rounded-lg bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300"
                >
                  Next Pair
                </button>
              </div>
            </div>

            <h3 className="text-xl font-bold text-slate-900 dark:text-white mb-6">
              Distinguishing: {currentHomoItem.pair.join(' vs ')}
            </h3>

            {/* Side-by-side Explanations */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-6">
              {currentHomoItem.explanations.map((exp, i) => (
                <div
                  key={i}
                  className="bg-slate-50 dark:bg-slate-950 p-4 rounded-xl border border-slate-200 dark:border-slate-800"
                >
                  <div className="flex items-center justify-between gap-2 mb-1.5">
                    <span className="font-extrabold text-base text-amber-600 dark:text-amber-400 font-mono">
                      {exp.word}
                    </span>
                    <button
                      onClick={() => handlePlayVoice(exp.word)}
                      title="Listen"
                      className="p-1 text-slate-400 hover:text-slate-900 dark:hover:text-white"
                    >
                      <Volume2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                  <div className="text-[11px] text-slate-500 font-medium mb-2">
                    {exp.partOfSpeech}
                  </div>
                  <p className="text-xs text-slate-700 dark:text-slate-300 mb-2 font-medium">
                    {exp.meaning}
                  </p>
                  <p className="text-xs text-slate-500 dark:text-slate-400 italic">
                    "{exp.example}"
                  </p>
                </div>
              ))}
            </div>

            {/* Quick Practice Question */}
            <div className="bg-amber-50/50 dark:bg-amber-950/20 border border-amber-200/80 dark:border-amber-900/40 rounded-xl p-5">
              <h4 className="text-xs font-bold text-amber-800 dark:text-amber-300 uppercase tracking-wider mb-2">
                Quick Usage Check:
              </h4>
              <p className="text-sm font-semibold text-slate-900 dark:text-white mb-4">
                {currentHomoItem.quickQuiz.question}
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 mb-4">
                {currentHomoItem.quickQuiz.options.map((opt, i) => {
                  const isSelected = selectedHomoAnswer === opt;
                  const isCorrect = opt === currentHomoItem.quickQuiz.correctAnswer;
                  let style =
                    'border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300';
                  if (homoSubmitted) {
                    if (isCorrect) {
                      style =
                        'border-emerald-500 bg-emerald-50 dark:bg-emerald-950/40 text-emerald-800 dark:text-emerald-300 font-bold';
                    } else if (isSelected) {
                      style =
                        'border-red-500 bg-red-50 dark:bg-red-950/40 text-red-800 dark:text-red-300 line-through';
                    }
                  } else if (isSelected) {
                    style =
                      'border-amber-500 ring-2 ring-amber-500/30 bg-amber-50 dark:bg-amber-950/40 font-semibold';
                  }

                  return (
                    <button
                      key={i}
                      type="button"
                      onClick={() => !homoSubmitted && setSelectedHomoAnswer(opt)}
                      className={`p-3 text-left rounded-xl border text-xs transition-colors cursor-pointer ${style}`}
                    >
                      {opt}
                    </button>
                  );
                })}
              </div>

              {!homoSubmitted ? (
                <button
                  type="button"
                  disabled={!selectedHomoAnswer}
                  onClick={() => {
                    setHomoSubmitted(true);
                    if (selectedHomoAnswer === currentHomoItem.quickQuiz.correctAnswer) {
                      confetti({ particleCount: 30, spread: 45, origin: { y: 0.7 } });
                    }
                  }}
                  className="px-4 py-2 bg-slate-900 hover:bg-slate-800 dark:bg-amber-500 dark:hover:bg-amber-600 text-white dark:text-slate-950 text-xs font-bold rounded-lg transition-colors disabled:opacity-50 cursor-pointer"
                >
                  Check Answer
                </button>
              ) : (
                <div className="flex items-center justify-between gap-3 text-xs">
                  <span className="text-slate-600 dark:text-slate-300 font-medium">
                    💡 {currentHomoItem.quickQuiz.hint}
                  </span>
                  <button
                    onClick={() => {
                      setHomoSubmitted(false);
                      setSelectedHomoAnswer(null);
                      setHomophoneIndex((prev) => (prev < currentHomophones.length - 1 ? prev + 1 : 0));
                    }}
                    className="font-bold text-amber-600 hover:underline"
                  >
                    Next Question →
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* SUB-TAB 4: SILENT LETTERS GUIDE */}
      {activeSubTab === 'silent' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            {SILENT_LETTER_RULES.map((rule, idx) => (
              <div
                key={idx}
                className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 shadow-xs flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between gap-2 mb-2">
                    <h3 className="text-lg font-bold text-slate-900 dark:text-white">
                      {rule.letter}
                    </h3>
                    <span className="text-xs font-semibold px-2 py-0.5 rounded-md bg-amber-100 dark:bg-amber-950/60 text-amber-800 dark:text-amber-300">
                      Rule #{idx + 1}
                    </span>
                  </div>
                  <p className="text-xs text-slate-600 dark:text-slate-400 mb-4 leading-relaxed">
                    {rule.rule}
                  </p>

                  <div className="space-y-1.5 mb-4">
                    <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider block">
                      Common Authentic Examples:
                    </span>
                    <div className="flex flex-wrap gap-2">
                      {rule.examples.map((ex, i) => (
                        <button
                          key={i}
                          onClick={() => handlePlayVoice(ex.split(' ')[0])}
                          className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-xs font-medium text-slate-800 dark:text-slate-200 transition-colors"
                        >
                          <Volume2 className="w-3 h-3 text-amber-600" />
                          <span>{ex}</span>
                        </button>
                      ))}
                    </div>
                  </div>
                </div>

                <div className="pt-3 border-t border-slate-100 dark:border-slate-800 text-xs text-slate-600 dark:text-slate-400">
                  👄 <span className="font-semibold text-slate-800 dark:text-slate-200">Mouth Tip:</span>{' '}
                  {rule.speakingTip}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
